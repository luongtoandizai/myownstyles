<?php return array (
  'currency' => 'GBP',
  'password' => '4cb9c8a8048fd02294477fcb1a41191a',
  'site_name' => 'PrintPixel',
  'currency_symbol' => '£',
  'default_product' => 'men-s-premium-t-shirt',
  'email' => 'test@test.com',
  'site_url' => '',
  'language' => 'en',
  'print_format' => 'pdf',
);