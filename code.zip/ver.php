<?php 
echo "Last updated 26 Aug 2015";
if (isset($_GET['info'])){
phpinfo();
}
?>