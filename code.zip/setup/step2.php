<?php
ob_start(); 
session_start();
include_once ("includes/header.php");
if (!isset($_SESSION['db_settings'])){
  header("Location:index.php");
}
// Step 1 is completed now check post values of step 2 
$errors = false;
$error_text = "";

// Db Crediantials
$admin_name  = "";
$admin_email = "";
$admin_pass = "";
$admin_repass = "";

if (isset($_SESSION['admin_details'])){
  // if its from step 2 to step 1 
  $admin_name = $_SESSION['admin_details']['admin_name'];
  $admin_email = $_SESSION['admin_details']['admin_email'];
  
}


if (isset($_POST['admin_name'])){
// Collect values from post
$admin_name = $_POST['admin_name'];
$admin_email = $_POST['admin_email'];
$admin_pass = $_POST['admin_pass'];
$admin_repass = $_POST['admin_repass'];
// now check if all fields are required 
if ($admin_name == "" || $admin_email == "" || $admin_pass =="" || $admin_repass ==""){
  $errors = true;
  $error_text = "Please Fill in required fields";
}

if (!$errors) {
  // Required fields are filled 
  // now its turn to validate email address
if (filter_var($admin_email, FILTER_VALIDATE_EMAIL)){
  // Email is valid
}else {
// Email is not valid 
  $errors = true;
  $error_text = "Invalid Email Address";
}

}


if (!$errors){
 // now match the passwords 
  if ($admin_pass !==$admin_repass){
    $errors = true;
    $error_text = "Passwords didnt matched";
  }

}


if (!$errors){
  // Database settings provided are correct now save it to session and move to step2
$admin_details = array ();
$admin_details ['admin_name'] = $admin_name;
$admin_details ['admin_email'] = $admin_email;
$admin_details ['admin_pass'] = $admin_pass;
$_SESSION['admin_details'] = $admin_details;
header("Location:step3.php");
}




}

?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Administrator Settings <small>Step 2/3</small></h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-file-o"></i> Database Settings</a></li>
              <li class="active"><i class="fa fa-user"></i> Administrator Settings</li>
            </ol>
            <?php 
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>
              
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-8">
              
            <form role="form" method="post">

              <div class="form-group">
                <label>Administrator's Name <span class="required">*</span></label>
                <input class="form-control" name="admin_name" placeholder="Enter full name" value="<?php echo $admin_name;?>">
                <p class="help-block">Please Provide Full Name.</p>
              </div>

              <div class="form-group">
                <label>Administrator's Email Address <span class="required">*</span></label>
                <input class="form-control" name="admin_email" placeholder="Enter email address" value="<?php echo $admin_email;?>">
                  <p class="help-block">Will be used to login.</p>
              </div>
                <div class="form-group">
                    <label>Administrator's Account Password <span class="required">*</span></label>
                    <input class="form-control" name="admin_pass" placeholder="Enter password" type="password">
                    <p class="help-block">We recommend combination of alphanumeric characters.</p>
                </div>

                <div class="form-group">
                    <label>Confirm Administrator's Account Password <span class="required">*</span></label>
                    <input class="form-control" name="admin_repass" placeholder="Re-type password" type="password">

                </div>

              <button type="submit" class="btn btn-primary">Proceed to Step - 3</button>
              <button type="reset" class="btn btn-default">Reset</button>

            </form>

          </div>


        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
<?php 
include_once ("includes/footer.php");
?>