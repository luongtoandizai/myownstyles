<?php 
ob_start();
session_start();
include_once ("includes/header.php");
if (!isset($_SESSION['admin_details'])){
  header("Location:step2.php");
}

$errors = false;
$error_text = "";

$site_name = "";
$fb_secret = "";
$fb_app_id = "";
$google_analytics = "";
$facebook_link = "";
$twitter_link= "";
$globe_link = "";
$google_link = "";
$pintrest_link = "";
$dots_link = "";
$youtube_link = "";
$entries_per_user = "";
$terms_conditions = "";
$number_of_votes=   "";
$votes_days = "";
$start_date = "";
$end_date = "";
$end_date_message = "";
$share_text_title = "";
$share_text_sub_title = "";
$share_text_description = "";
$voting_choice = "";
$favicon = "";
if (isset($_SESSION['site_settings'])){
$site_settings =  $_SESSION['site_settings'];


$site_name = $site_settings['site_name'];
$fb_secret = $site_settings['fb_secret'];
$fb_app_id = $site_settings['fb_app_id'];
$google_analytics = $site_settings['google_analytics'];
$twitter_link = $site_settings['twitter_link'];
$facebook_link = $site_settings['facebook_link'];
$globe_link = $site_settings['globe_link'];
$google_link = $site_settings['google_link'];
$pintrest_link = $site_settings['pintrest_link'];
$dots_link = $site_settings['dots_link'];
$youtube_link = $site_settings['youtube_link'];
$entries_per_user = $site_settings['entries_per_user'];
$terms_conditions = $site_settings['terms_conditions'];
$number_of_votes=   $site_settings['number_of_votes'];
$votes_days = $site_settings['votes_days'];
$start_date = $site_settings['start_date'];
$end_date = $site_settings['end_date'];
$end_date_message = $site_settings['end_date_message'];
$share_text_title = $site_settings['share_text_title'];
$share_text_sub_title = $site_settings['share_text_sub_title'];
$share_text_description = $site_settings['share_text_description'];
$voting_choice = $site_settings['voting_choice'];
$favicon = $site_settings['favicon'];

}




if (isset($_POST['site_name'])){

$_SESSION['site_settings']=$_POST;

$site_name = $_POST['site_name'];
$fb_secret = $_POST['fb_secret'];
$fb_app_id = $_POST['fb_app_id'];
$google_analytics = $_POST['google_analytics'];
$facebook_link = $_POST['facebook_link'];
$twitter_link = $_POST['twitter_link'];
$globe_link = $_POST['globe_link'];
$google_link = $_POST['google_link'];
$pintrest_link = $_POST['pintrest_link'];
$dots_link = $_POST['dots_link'];
$youtube_link = $_POST['youtube_link'];
$entries_per_user = $_POST['entries_per_user'];
$terms_conditions = $_POST['terms_conditions'];
$number_of_votes=   $_POST['number_of_votes'];
$votes_days = $_POST['votes_days'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$end_date_message = $_POST['end_date_message'];
$share_text_title = $_POST['share_text_title'];
$share_text_sub_title = $_POST['share_text_sub_title'];
$share_text_description = $_POST['share_text_description'];
$voting_choice = $_POST['voting_choice'];






if (!$errors){

// Uploading of avatar started 
if((!empty($_FILES["favicon"])) && ($_FILES['favicon']['error'] == 0)) {
  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['favicon']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["favicon"]["tmp_name"]);
  $height = $dimensions[0];
  $width = $dimensions[1];
  if (($ext == "jpg" || $ext == "JPG" || $ext == "jpeg" || $ext == "JPEG"|| $ext == "PNG"|| $ext == "png" || $ext == "GIF" || $ext == "gif")) {
    //Determine the path to which we want to save this file
      $fname=rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['favicon']['tmp_name'],$newname))) {
            $_SESSION['site_settings']['favicon']= $fname;

        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during Favicon upload!";          
        }
      } else {         
      }
  } else {
           $errors = true;
          $error_text = "Error: Invalid Favicon";          
                
  }
}else{
  $_SESSION['site_settings']['favicon']= "";
} 
}



if (!$errors){

// Uploading of avatar started 
if((!empty($_FILES["logo"])) && ($_FILES['logo']['error'] == 0)) {
  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['logo']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["logo"]["tmp_name"]);
  $height = $dimensions[0];
  $width = $dimensions[1];
  if (($ext == "jpg") && ($_FILES["logo"]["type"] == "image/jpeg") ) {
    //Determine the path to which we want to save this file
       $fname=rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['logo']['tmp_name'],$newname))) {
            $_SESSION['site_settings']['logo']= $fname;
        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during Logo upload!";          
        }
      } else {
         $errors = true;
          $error_text = "Error: File with this name already exists.";      
      }
  } else {
                 
  }
}else {
   $_SESSION['site_settings']['logo']= "";
} 
}

$banners = array();
if (!$errors){

// Uploading of avatar started 

if((!empty($_FILES["sliders"]['name'][0]))) {

for ($i=0 ; $i<count($_FILES['sliders']['name']) ; $i++){


  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['sliders']['name'][$i]);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["sliders"]["tmp_name"][$i]);
  $height = $dimensions[0];
  $width = $dimensions[1];
  if (($ext == "jpg") && ($_FILES["sliders"]["type"][$i] == "image/jpeg") ) {
    //Determine the path to which we want to save this file
       $fname=rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['sliders']['tmp_name'][$i],$newname))) {
            $banners[]= $fname;
        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during Sliders upload!";          
        }
      } else {         
      }
  } else {
               
  }



}// for loop

if (!$errors){
  // There are no erros and all photos uploaded 
  // now save their names to databse table 
  $_SESSION['banners'] = $banners;
}


} 
}





if (!$errors){
  // Files uploaded 
  // now its turn to create the database tables and complete setup 
  header("Location:finalize.php");

}


  
}



?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Site Settings <small>Step 3/3</small></h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><i class="fa fa-user"></i> Administrator Settings</li>
              <li class="active"><i class="fa fa-wrench"></i> Site Settings</li>
            </ol>


            <?php 
              if (isset($_GET['page_added'])){?>

              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  App Added to Fanpage
              </div>

              <?php }

            ?>
           
              <?php 
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-8">
              <form role="form" method="POST"  enctype="multipart/form-data">

                               <div class="form-group">
                <label>Site Name</label>
                <input class="form-control" name="site_name" value="<?php echo $site_name;?>">
                <p class="help-block">Name will be used in titles and email notifications etc.</p>
              </div>


              <div class="form-group">
                <label>Site Logo</label>
                <input type="file" name="logo">
                <p class="help-block">Diamensions should be 100 x 60.</p>
              </div>
              <div class="form-group">
                <label>Site Favicon</label>
                <input type="file" name="favicon">
                <p class="help-block">Recommended Dimensions 32x32.</p>
              </div>

                <div class="form-group">
                    <label>Facebook Application ID</label>
                    <input class="form-control fb_app_id" name="fb_app_id"  value="<?php echo $fb_app_id;?>">
                    <p class="help-block">Will be used for Log in with Facebook button.</p>
                </div>
                <div class="form-group">
                    <label>Facebook Secret</label>
                    <input class="form-control" name="fb_secret" value="<?php echo $fb_secret;?>">
                    <p class="help-block">Facebook Secret</p>
                </div>

               
              
              <div class="form-group">
                    <label>Facebook Link</label>
                    <input class="form-control" name="facebook_link" value="<?php echo $facebook_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>

          <div class="form-group">
                    <label>Twitter Link</label>
                    <input class="form-control" name="twitter_link" value="<?php echo $twitter_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>

          <div class="form-group">
                    <label>Google Plus Link</label>
                    <input class="form-control" name="google_link" value="<?php echo $google_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Globe Link</label>
                    <input class="form-control" name="globe_link" value="<?php echo $globe_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Pintrest Link</label>
                    <input class="form-control" name="pintrest_link" value="<?php echo $pintrest_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Dots Link</label>
                    <input class="form-control" name="dots_link" value="<?php echo $dots_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Youtube Link</label>
                    <input class="form-control" name="youtube_link" value="<?php echo $youtube_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>

          <div class="form-group">
                    <label>Entries Allowed per user</label>
                    <input class="form-control" name="entries_per_user" value="<?php echo $entries_per_user;?>">
                    <p class="help-block">Number of entries allowed per user</p>
          </div>
          <div class="form-group" style="display:none;">
                    <label>Voters Permission</label>
                    <input type="checkbox" class="form-control small" name="voters_permission">
                    <p class="help-block">If voters are required to give permissions before voting </p>
          </div>
          <?php 
          ?>
              <div class="form-group">
                <label>Terms And Conditions</label>
                <textarea class="form-control" rows="3" name="terms_conditions"><?php echo $terms_conditions;?></textarea>
              </div>
          <div class="form-group">
                    <label>Voting limit Choice</label>
              <select name="voting_choice" class="form-control">
                <option value="1">Per Photo</option>
                <option value="2">Whole Contest</option>
              </select>
                    <p class="help-block">Per Photo / Per User</p>
          </div>    

          <div class="form-group">
                    <label>Votes (Number of votes)</label>
                    <input class="form-control" name="number_of_votes" value="<?php echo $number_of_votes;?>">
                    <p class="help-block">Number of votes </p>
          </div>

          <div class="form-group">
                    <label>Votes (days)</label>
                    <input class="form-control" name="votes_days" value="<?php echo $votes_days;?>">
                    <p class="help-block">Votes (Days)</p>
          </div>
          
          <div class="form-group">
                    <label>Start Date</label>
                    <input class="form-control start_date" name="start_date" value="<?php echo $start_date;?>">
                    <p class="help-block">Start Date</p>
          </div>
          <div class="form-group">
                    <label>End Date</label>
                    <input class="form-control end_date" name="end_date" value="<?php echo $end_date;?>">
                    <p class="help-block">End Date</p>
          </div>
          <div class="form-group">
                    <label>End Date Message</label>
                    <input class="form-control" name="end_date_message" value="<?php echo $end_date_message;?>">
                    <p class="help-block">End Date Message</p>
          </div>

          <div class="form-group">
                    <label>Share Text Title</label>
                    <input class="form-control" name="share_text_title" value="<?php echo $share_text_title;?>">
                    <p class="help-block">Share Text Title</p>
          </div>
          <div class="form-group">
                    <label>Share Text Sub Title</label>
                    <input class="form-control" name="share_text_sub_title" value="<?php echo $share_text_sub_title;?>">
                    <p class="help-block">Share Text Sub Title</p>
          </div>
          
              <div class="form-group">
                <label>Share Text Description</label>
                <textarea class="form-control" rows="3" name="share_text_description"><?php echo $share_text_description;?></textarea>
              </div>

              <div class="form-group">
                <label>Admin Permission To Approve Entry</label>
              <select name="admin_approval_entry" class="form-control">
                <option value="1">Yes</option>
                <option value="0">No</option>
              </select>
              </div>
              <div class="form-group">
                      <label>Slide Banners</label>
                      <input type="file" name="sliders[]" multiple="true">
                      <p class="help-block">Appears in Front Banners</p><br/>
                  </div>


              <div class="form-group">
                <label>Google Analytics</label>
                <textarea class="form-control" rows="3" name="google_analytics"><?php echo $google_analytics;?></textarea>
              </div>

                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a class="add_app_to_page" href="javascript:void(0)" class="btn btn-default">
                      Add App To Fan Page
                  </a>
                  <input type="hidden" name="activation_key" value=""/>
                  <input type="hidden" name="fan_page_url" value=""/>
                  <input type="hidden" name="main_site_url" value=""/>
              </form>

          </div>


        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->
    <?php 
    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    ?>
  <?php include_once("includes/footer.php"); ?>
  <script>
  var redirect_url = "<?php echo $actual_link?>";
  $(document).ready (function (){

    $(".add_app_to_page").on ("click",function (){
      // on clicking the button add app to facebook page
      var app_id = $(".fb_app_id").val();
      if (app_id==""){
        alert ("Please Enter App ID First");
      }else {
        var final_redirect_url = "https://www.facebook.com/dialog/pagetab?app_id="+app_id+"&redirect_uri="+redirect_url+"?page_added=1";
        Location.href=final_redirect_url;
        window.location.assign(final_redirect_url);

      }
    });

  })
  </script>
  <script type="text/javascript">
      jQuery(document).ready (function (){
        $( ".start_date" ).datepicker();
        $( ".end_date" ).datepicker();
      })

      </script>