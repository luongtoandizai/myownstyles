<?php 
ob_start();
session_start();

$db_settings = $_SESSION['db_settings'];
$prefix = $db_settings['prefix'];
mysql_connect($db_settings['db_host'], $db_settings['db_user'], $db_settings['db_pass']);
mysql_select_db($db_settings['db_name']);

$q1 = "
CREATE TABLE IF NOT EXISTS `".$prefix."admin_login` (
`id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `resetcode` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

$q2="
CREATE TABLE IF NOT EXISTS `".$prefix."site_settings` (
`id` int(11) NOT NULL,
  `settings_title` varchar(100) NOT NULL,
  `settings_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

 $q7="
CREATE TABLE IF NOT EXISTS `".$prefix."banners` (
`id` int(11) NOT NULL,
  `banner` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

//  Queries to create entries table

$entries_query1="
CREATE TABLE IF NOT EXISTS `".$prefix."entries` (
`id` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `approved` int(11) NOT NULL    	
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

$entries_query2="
ALTER TABLE `".$prefix."entries`
 ADD PRIMARY KEY (`id`);";

$entries_query3="
ALTER TABLE `".$prefix."entries`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";

// Create users table 

$users_query1="
CREATE TABLE IF NOT EXISTS `".$prefix."users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `entered` int(11) NOT NULL,
  `fbid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

$users_query2="
ALTER TABLE `".$prefix."users`
 ADD PRIMARY KEY (`user_id`);";

$users_query3="
ALTER TABLE `".$prefix."users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;";


// Create the voting table 
$vote_query1="
CREATE TABLE IF NOT EXISTS `".$prefix."votes` (
  `vote_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created` datetime NOT NULL       
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

$vote_query2="
ALTER TABLE `".$prefix."votes`
 ADD PRIMARY KEY (`vote_id`);";

$vote_query3="
ALTER TABLE `".$prefix."votes`
MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT;";






$q3="
ALTER TABLE `".$prefix."admin_login`
 ADD PRIMARY KEY (`id`);";

$q8="
ALTER TABLE `".$prefix."banners`
 ADD PRIMARY KEY (`id`);";



$q4=" 
ALTER TABLE `".$prefix."site_settings`
 ADD PRIMARY KEY (`id`);";
$q5=" 
ALTER TABLE `".$prefix."admin_login`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";

$q6="
ALTER TABLE `".$prefix."site_settings`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";
$q9="
ALTER TABLE `".$prefix."banners`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";

mysql_query($q1);
mysql_query($q2);
mysql_query($q3);
mysql_query($q4);
mysql_query($q5);
mysql_query($q6);
mysql_query($q7);
mysql_query($q8);
mysql_query($q9);
// Entries Query 
mysql_query($entries_query1);
mysql_query($entries_query2);
mysql_query($entries_query3);
// Users Query 
mysql_query($users_query1);
mysql_query($users_query2);
mysql_query($users_query3);
// Votes Query 
mysql_query($vote_query1);
mysql_query($vote_query2);
mysql_query($vote_query3);


$admin_details = $_SESSION['admin_details'];
$admin_name = $admin_details['admin_name'];
$admin_email = $admin_details['admin_email'];
$admin_password = $admin_details['admin_pass'];
$admin_query = "insert into ".$prefix."admin_login values ('', '".$admin_name."' , '".$admin_email."' , '".md5($admin_password)."','')";
mysql_query($admin_query);

$site_settings = $_SESSION['site_settings'];
foreach ($site_settings as $key => $value) {
$settings_query = "insert into ".$prefix."site_settings values ('', '".$key."' , '".$value."')";
 mysql_query($settings_query);	
}

if (isset($_SESSION['banners'])){
$banners = $_SESSION['banners'];

$truncate_query = "TRUNCATE ".$prefix."banners";
  mysql_query($truncate_query);
  foreach ($banners as $banner) {
    $insert_banner_query = "insert into ".$prefix."banners values ('', '".$banner."')";
    mysql_query($insert_banner_query);  

  }
}

$string = '<?php 
define("DB_HOST", "'. $db_settings['db_host']. '", true);
define("DB_USERNAME", "'. $db_settings['db_user']. '", true);
define("DB_PASSWORD", "'. $db_settings['db_pass']. '", true);
define("DB_NAME", "'. $db_settings['db_name']. '", true);
define("PREFIX", "'. $db_settings['prefix']. '", true);
define("PRODUCTID", "9348215", true);
?>';
$fp = fopen("../config.php", "w");
fwrite($fp, $string);
fclose($fp);
header("location:add_app.php");

?>