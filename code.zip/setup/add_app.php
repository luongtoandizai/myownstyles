<?php 
ob_start();
session_start();
if (isset($_GET['page_added'])){
	header("location:../admin/login.php");
	exit();
}
$app_id=$_SESSION['site_settings']['fb_app_id'];
$add_app_id = "http://www.facebook.com/add.php?api_key=$app_id&pages";
echo "Congtratulation!  Setup of the app is complete.";
if ($app_id!==""){
echo " Please click <a target='_BLANK' href='".$add_app_id."'>here</a> to add this app to your fan page.";
}
echo " You can click <a href='../admin/login.php'>here</a> to login to your admin panel.";
?>

