<?php 
ob_start();
session_start();
include_once("includes/header.php");
    if (file_exists("../config.php")){
    // Setup is installed
    header("Location: ../index.php");
        exit ();
    }

$errors = false;
$error_text = "";

// Db Crediantials
$db_name = "";
$db_user = "";
$db_pass = "";
$db_host = "";
$prefix = "ca_";

if (isset($_SESSION['db_settings'])){
  // if its from step 2 to step 1 
  $db_name = $_SESSION['db_settings']['db_name'];
  $db_user = $_SESSION['db_settings']['db_user'];
  $db_host = $_SESSION['db_settings']['db_host'];
  $prefix =  $_SESSION['db_settings']['prefix'];
}

if (isset($_POST['dbname'])){

//Grab post values of form 
$db_name = $_POST['dbname'];
$db_user = $_POST['dbuser'];
$db_pass = $_POST['dbpass'];
$db_host = $_POST['dbhost'];
$prefix = $_POST ['prefix'];
// Now validates the form values for required 

if ($db_name == ""){
  $error_text = "Please Fill in required values";
  $errors = true;
}
if ($db_user == ""){
  $error_text = "Please Fill in required values";
  $errors = true;
}
if ($db_host == ""){
  $error_text = "Please Fill in required values";
  $errors = true;
}
if ($prefix == ""){
  $error_text = "Please Fill in required values";
  $errors = true;
}
// if required fields are provided then try to connect using provided settings

if (!$errors){
  if (strstr($db_user, '$') || strstr($db_user, '"') || strstr($db_user, "'" )|| strstr($db_user, "%")){
    // Strings found that can break
  $error_text = "Username Cannot Contain dollar sign or any sort of quotes";
  $errors = true;   
  }

}
if (!$errors){
  if (strstr($db_pass, '$') || strstr($db_pass, '"') || strstr($db_pass, "'" )|| strstr($db_user, "%")){
    // Strings found that can break
  $error_text = "Password Cannot Contain dollar sign or any sort of quotes";
  $errors = true;   
  }

}


if (!$errors){
 error_reporting(0);
$link = mysql_connect($db_host, $db_user, $db_pass);
if (!$link) {
  $errors = true;
  $error_text = "Invalid Crediantials of Database";
}
}
 // Now try to select the provided databases
 if (!$errors){
  if (!mysql_select_db($db_name)){
    $errors = true;
    $error_text = mysql_error();
  }
 }


if (!$errors){
  
$link = mysql_connect($db_host, $db_user, $db_pass);
mysql_select_db($db_name);
$test_query="
CREATE TABLE IF NOT EXISTS `test_table` (
`id` int(11) NOT NULL,
  `testfield` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

if (!mysql_query($test_query)){
$errors = true;
$error_text = "Please Ensure Assign All Previlages to Db User";
}

if (!$errors){
$test_insert = "insert into test_table values ('1', 'test')"; 
if (!mysql_query($test_insert)){
$errors = true;
$error_text = "Please Ensure Assign All Previlages to Db User";
}
}

if (!$errors){
$test_update = "update test_table set testfield = 'new' where id='1'"; 
if (!mysql_query($test_update)){
$errors = true;
$error_text = "Please Ensure Assign All Previlages to Db User";
}
}

if (!$errors){
$test_delete = "delete from test_table"; 
if (!mysql_query($test_delete)){
$errors = true;
$error_text = "Please Ensure Assign All Previlages to Db User";
}
}

  
}





if (!$errors){

  // Database settings provided are correct now save it to session and move to step2
$db_settings = array ();
$db_settings ['db_name'] = $db_name;
$db_settings ['db_user'] = $db_user;
$db_settings ['db_pass'] = $db_pass;
$db_settings ['db_host'] = $db_host;
$db_settings['prefix'] = $prefix;
$_SESSION['db_settings'] = $db_settings;
header("Location: step2.php");
exit();
}


}// post if closing

$notification_errors = array ();
$notification_success = array ();

// PHP Version Check 

if (version_compare(PHP_VERSION, '5.4.0', '>=')) {
$notification_success[] = "PHP Version is OK";
}else {
  $notification_errors[] = "PHP Version 5.4 or later required";
}
// Main Root Directory Check 
if (is_writable("../")){
  $notification_success[] = "Root Directory is writeable";
}else{
  $notification_errors[] = "Root Directory must have 777 permissions.";
}
// Upload Directory Cehck 

if (is_writable("../uploads/")){
  $notification_success[] = "Upload Directory is writeable.";
}else{
  $notification_errors[] = "Upload Directory must have 777 permissions.";
}
// MB SubSTR Function check 
if(function_exists('mb_substr')){
$notification_success[] = "mb_substr() module is enabled.";
}else{
$notification_errors[] = "mb_substr() module is needed. Click <a target='_BLANK' href='http://php.net/manual/en/mbstring.installation.php'> here </a> For Solution.";
}
  

?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Database Settings <small>Step 1/3</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-file-o"></i> Step-1 Data Base Settings</a></li>
            </ol>
            <!-- <div class="alert alert-info alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                New Settings have been saved
            </div> -->
            
            <?php 
            if (count($notification_success)>0){?>
              <div class="alert alert-success">
              <?php foreach ($notification_success as $key => $success) {?>
                  <?php echo $success;?>&nbsp; &#10004;<br/>
              <?php }?>
              </div>
           <?php }
            ?>  

            <?php 
            if (count($notification_errors)>0){?>         
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php foreach ($notification_errors as $key => $error) {?>
                  <?php echo $error;?>
              <?php }?>
              </div>
           <?php }
            ?>

                          

            <?php
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-8">
              
            <form role="form" method="post">
                <div class="form-group">
                    <label>Database Name <span class="required">*</span></label>
                    <input class="form-control" name="dbname" value ="<?php echo $db_name;?>">
                    <p class="help-block">Name of database you want to use.</p>
                </div>
              <div class="form-group">
                <label>Database User Name <span class="required">*</span></label>
                <input class="form-control" name="dbuser" value ="<?php echo $db_user;?>">
                  <p class="help-block">Username for accessing above database</p>
              </div>
                <div class="form-group">
                    <label>Database Password</label>
                    <input class="form-control" type="password" name="dbpass">
                    <p class="help-block">Avoid Special Characters specially quotes dollar sign and % sign or _</p>
                </div>
                <div class="form-group">
                    <label>Host Name <span class="required">*</span></label>
                    <input class="form-control" name="dbhost" value ="<?php echo $db_host;?>">
                    <p class="help-block">In most of cases it is localhost.</p>
                </div>
                <div class="form-group">
                    <label>Tables_prefix <span class="required">*</span></label>
                    <input class="form-control" name="prefix" value ="<?php echo $prefix;?>">
                    <p class="help-block">like ca_</p>
                </div>

              <button type="submit" class="btn btn-primary">Proceed to Step - 2 </button>
            </form>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
    </div><!-- /#wrapper -->
  <?php 
  include_once("includes/footer.php");
  ?>