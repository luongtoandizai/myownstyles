<?php
include_once ("includes/ajax.php");
	if ($_POST['ajax']){
		if(session_id() == '') {
    		session_start();
		}
		switch ($_POST['method']) {
			case 'vote':
				$entry_id = $_POST['eid'];
				$email = $_POST['email'];
				$votes=$db->insert_vote($entry_id,$email);	
				echo $votes;
				break;
			case 'redirect':
				$_SESSION['eid'] = $_POST['eid'];	
				break;
			default:
				# code...
				break;
		}

	}


?>
