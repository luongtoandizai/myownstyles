<?php
if (file_exists(__DIR__."/config.php")){
}else {
	// Setup is not installed yet
	header("Location: setup");
}

	

	include_once ("includes/header.php");



	$front_banners_res = $db->get_front_banners();
	$start_date = "";
	$end_date = "";
	$settings_start = $db->get_settings_by_setting_name("start_date");
	$settings_end = $db->get_settings_by_setting_name("end_date");
	$start_date = $settings_start['settings_value'];
	$end_date = $settings_end ['settings_value'];
	$contest_over = false;
    
	if ($start_date == "" || $end_date == ""){
		// Contest start and end didnt configured yet
		 
	}else {
		// Contest is configured 
		$paymentDate = date('Y-m-d');
    $paymentDate=date('Y-m-d', strtotime($paymentDate));;
    //echo $paymentDate; // echos today! 
    $contractDateBegin = date('Y-m-d', strtotime($start_date));
    $contractDateEnd = date('Y-m-d', strtotime($end_date));
    if (($paymentDate > $contractDateBegin) && ($paymentDate < $contractDateEnd))
    {
      
    }
    else
    {
    	if ($paymentDate < $contractDateEnd){
    		
    	}else {
    		$contest_over = true;		
    	}
      
    }
	}
	$entries = $db->get_random_entries_front($contest_over);	
	?>
		<div id="photo-slider">
		
			<div id="photo-carousel" class="carousel slide" data-ride="carousel">
				  <!-- Wrapper for slides -->
				  <div class="carousel-inner">
				  	
				  	<?php if ($front_banners_res){?>

				  	<?php 
				  	$c=0;
				  	$class="active";
				  	foreach ($front_banners_res as $banner) {
				  		if ($c>0){
				  			$class = "";
				  		}
				  		?>
				  	<div class="item <?php echo $class;?>">
					  <img class="img-responsive " src="<?php echo "uploads/".$banner;?>" alt="">
					</div>

				  	<?php $c++; }

				  	?>


				  	<?php }else {?>
				  	<div class="item active">
					  <img class="img-responsive" src="./img/slider.jpg" alt="">
					</div>
				  	<?php }?>

					
					
				  </div>

				  <!-- Controls -->
				  <a class="left carousel-control" href="#photo-carousel" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left"></span>
				  </a>
				  <a class="right carousel-control" href="#photo-carousel" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right"></span>
				  </a>
				</div>

		</div>
		
		<div class="border-bg" style="height:2px"></div>
	
	<div class="clearfix"></div> 
	<?php 
	global $enter_contest_url;
	?>
		<section id="connected">
			<div class="fix container">
				<div class="fix row">
					<div class="fix col-sm-12 text-center">
						<div class="fix fb-contacted">
							<h2><?php echo $lang_heading_home_page;?></h2>
							<h3><?php echo $lang_sub_heading_home_page;?></h3>
							<?php if ($fb_logged_in){
								$target ="";
							}else {
								$target ='target="_top"';
							}?>
							<a href="<?php echo  $enter_contest_url;?>" <?php echo $target;?> class="btn btn-md btn-enter"><?php echo $lang_button_home_page;?></a>
						</div>
					</div>
				</div>
			</div>
		</section>
	
	<div class="clearfix"></div> 
	
	<div class="border-bg"></div>
	


<section id="page-gallery">
			<div class="fix container">
				<div class="fix row">
					<h1><?php
					$winners = false;
					if ($entries['result_type'] == "Random Entries"){
						echo $lang_random_entries;
					}else {
						echo $lang_winners_of_contest;
						$winners = true;
					}

					
					 ?></h1>
					<div class="fix col-sm-12 gallery">
						
						<?php 
						if ($entries['entries']){?>
						<?php 
						$winners_text = array("3rd","2nd","1st");
						foreach ($entries['entries'] as $key => $value) {
							$id = $value['id'];
							?>
						
												<!-- Gallery Items  -->
					
						<div class="fix col-sm-4">
							<div class="fix gallery-item">
							
							<!-- Modal Tiger  and Thumbnails-->
							
								<a data-toggle="modal" href="#modal-item-<?php echo $value['id']?>" >
									<img class="photo_<?php echo $id;?>" src="uploads/<?php echo $value ['photo']?>" alt="" />
								</a>
								
							<!-- thumbnails Share info -->
							
								<div class="item-info">
									<ul class="post-info">
										<li><?php echo $lang_by_text;?>: <span><?php echo $value['first_name'] . " ". $value['last_name'];?></span> </li>
										<li><?php echo $lang_votes_text;?>: <span class="vote_count_<?php echo $value['id'];?>"><?php echo $value['votes'];?></span></li>
									</ul>
									<ul class="share">
										<li class="share_to_fb" data-id="<?php echo $value['id']?>"><?php echo $lang_share_text;?></li>
										

											<?php if ($fb_logged_in){?>
                                            <li class="vote" data-id="<?php echo $value['id'];?>">
												<?php echo $lang_vote_text;?>
											<?php }else{?>
                                                <li class="vote" data-id="<?php echo "null";?>" > 
                                                <a data-id2="<?php echo $value['id'];?>" href="<?php  if (!$fb_logged_in && !$inside_fb){ echo $enter_contest_url;}else { echo str_replace('dummy',$value['id'], $enter_contest_url);} ?>" target="_top"><?php echo $lang_vote_text;?></a>
										</li>
										<?php }?>
										
									</ul>
									<?php if ($winners){?>
									<p>Position: <strong><?php echo $winners_text[$key];?></strong></p>
									<?php } ?>
									
								</div>

								
							<!--  Main Modal With Large Image-->	
							
								<div class="modal fade" id="modal-item-<?php echo $value['id']?>" style="display:none">
								
									<div class="top-modal">
										<ul class="post-info">
											<li><?php echo $lang_by_text;?>: <span><?php echo $value['first_name']." ".$value['last_name'];?></span> </li>
										</ul>
										
										<ul class="close">
											<li class="modal-close" data-dismiss="modal">X</li>
										</ul>
									</div>
									
									<img src="uploads/<?php echo $value['photo'];?>" alt="" title="" />
									
									<div class="bottom-modal">
										<ul class="post-info">
											<li>Votes: <span class="vote_count_<?php echo $value['id'];?>"><?php echo $value['votes'];?></span></li>
										</ul>
										
										<ul class="share">
											<li class="share_to_fb" data-id="<?php echo $value['id']?>"><?php echo $lang_share_text;?></li>
											<?php if (!$winners){?>


												<?php if ($fb_logged_in){?>
                                                    <li class="vote" data-id="<?php echo $value['id'];?>" >
												<?php echo $lang_vote_text;?>
											<?php }else{?>
                                                    <li class="vote" data-id="<?php echo "null";?>" >
												<a data-id2="<?php echo $value['id'];?>" href="<?php  if (!$fb_logged_in && !$inside_fb){ echo $enter_contest_url;}else { echo str_replace('dummy',$value['id'], $enter_contest_url);} ?>" target="_top"><?php echo $lang_vote_text;?></a>
											<?php }?>
											
											</li>
											<?php }?>
											<li class="modal-close" data-dismiss="modal"><?php echo $lang_close_text;?></li>
										</ul>
									</div>	
								
								</div> 
								
								<!-- ./ Modal -->
								
								
							</div>
						</div>
						<!--  ./Gallery Items  -->


						<?php }
						?>






						<?php } else {?>
							<p><?php echo $lang_no_entries;?></p>
						<?php }
						?>


						
						<!-- Gallery Items  -->
					
						
						
						
					</div>
					
				</div>
			</div>
		</section>
	<!-- /.Enter page Are -->
	
	<div class="clearfix"></div>
	<?php include_once ("includes/footer.php");?>
	<?php 
    if (isset($_SESSION['user'])){
    	 $user =$_SESSION['user'];
    $facebook_email = $user->getProperty('email');
    }else {
    	$facebook_email="";
    }
    ?>
	<script type="text/javascript">
	jQuery (document).ready (function (){
		var f_email = "<?php echo $facebook_email;?>";
		jQuery (".vote").on ("click" , function(){
		var entry_id = jQuery(this).data("id");

		<?php if ($winners){?>
			alert ("You Cannot Vote Now Contest is Over");
		<?php }else {?>
            if (entry_id == null)
            {

                return;
            }

            jQuery (".vote_count_"+entry_id).html("<img src='img/ajax.gif'/>");
		jQuery.post ("ajax.php" , {"ajax":true ,"method":"vote", "eid":entry_id,"email":f_email} , function (response){
			jQuery (".vote_count_"+entry_id).html(response.votes_count);
			alert (response.message);
		},'json');

		<?php }?>
		

		});

	});

	</script>
	<?php 
	$settings_share_text_title = $db->get_settings_by_setting_name("share_text_title");
	$share_text_title = $settings_share_text_title['settings_value'];

	$settings_share_text_sub_title = $db->get_settings_by_setting_name("share_text_sub_title");
	$share_text_sub_title = $settings_share_text_sub_title['settings_value'];
	
	$settings_share_text_description = $db->get_settings_by_setting_name("share_text_description");
	$share_text_description = $settings_share_text_description['settings_value'];
	
	

	
	if (isset($_REQUEST['signed_request'])) {
	$signed_request = $_REQUEST['signed_request'];	
		$data_signed_request = explode('.',$signed_request); // Get the part of the signed_request we need.
	  $jsonData = base64_decode($data_signed_request['1']); // Base64 Decode signed_request making it JSON.
	  $objData = json_decode($jsonData,true); // Split the JSON into arrays.
	  $pageData = $objData['page'];

	  $liked = $pageData['liked']; //you have the liked boolean
	  $sourceData = $objData['app_data']; // yay you got the damn data in an string, slow clap for you
	  
	  if (!empty($sourceData) && !$entry_id){
	  	$entry_id = $sourceData;
	  }else{
	  	if (isset($_GET['app_data']) && !$entry_id){
	  			$entry_id = $_GET['app_data'];
	  	}
	  }	
	}else{
		if (!isset($_SESSION['signed_request'])){
			// It is accessed outside fb 
			if (isset($_GET['app_data']) && !$entry_id){
			$entry_id = $_GET['app_data'];		
			}

		}else{

		}
	}


	$share_url = "";
	$share_platform = "";
	if (contains('https://apps.facebook.com',$_SESSION['pageurl'])){
		// it is canvas app 
		$share_url = $_SESSION["pageurl"]."?app_data=";
		$share_platform = "canvas";
	}else{

	if ($inside_fb){
		$share_url = $_SESSION["pageurl"]."&app_data=";
		$share_platform = "fanpage";
	}else{
		$share_url = $_SESSION["pageurl"]."?app_data=";
		$share_platform = "website";
	}		

	}




	
$settings_site_url = $db ->get_settings_by_setting_name("main_site_url");
$main_site_url = $settings_site_url['settings_value'];
$share_url = $main_site_url."?platform=".$share_platform."&app_data=";

	function contains($needle, $haystack)
{
    return strpos($haystack, $needle) !== false;
}

	?>
	
	<?php 

	if (!empty($entry_id) && $entry_id!==""){
		// There is modal popup to show 
		$res_entry = $db->get_entry_by_id($entry_id);
		if ($res_entry){
			$value = mysql_fetch_array($res_entry);
			?>		

							<a data-toggle="modal" id="open_img_det" href="#popup_modal" style="display:none;">
									.
								</a>
										<!--  Main Modal With Large Image-->	
							
								<div class="modal fade" id="popup_modal" style="display:none">
								
									<div class="top-modal">
										<ul class="post-info">
											<li><?php echo $lang_by_text;?>: <span><?php echo $value['first_name']." ".$value['last_name'];?></span> </li>
										</ul>
										
										<ul class="close">
											<li class="modal-close" data-dismiss="modal">X</li>
										</ul>
									</div>
									
									<img src="uploads/<?php echo $value['photo'];?>" alt="" title="" />
									
									<div class="bottom-modal">
										<ul class="post-info">
											<li>Votes: <span class="vote_count_<?php echo $value['id'];?>"><?php echo $value['votes'];?></span></li>
										</ul>
										
										<ul class="share">
											<li class="share_to_fb" data-id="<?php echo $value['id']?>"><?php echo $lang_share_text;?></li>
											<?php if (!$winners){?>


												<?php if ($fb_logged_in){?>
                                                    <li class="vote" data-id="<?php echo $value['id'];?>">
												<?php echo $lang_vote_text;?>
											<?php }else{?>
                                                    <li class="vote" data-id="<?php echo "null";?>">
												<a href="<?php echo $enter_contest_url;?>" target="_top"><?php echo $lang_vote_text;?></a>
											<?php }?>
											
											</li>
											<?php }?>
											<li class="modal-close" data-dismiss="modal"><?php echo $lang_close_text;?></li>
										</ul>
									</div>	
								
								</div> 

		<?php }		
	}
	?>


	<script type="text/javascript">
            $( document ).ready(function() {
                // Share button has been given id share_btn and on click following handler is used
                $( ".share_to_fb" ).click(function() {

                    // Preparing required variables for FB.ui call
                    // To prepare these variables settings / variables from config.php file are used
                    var id = $(this).data("id");
                    var photo_element = $(".photo_"+id);
                    var img_src = $(photo_element)[0].src;
                    var img_src_new = img_src.replace("http://", ""); 
                    img_src_new = img_src.replace("https://", ""); 
                    
                    var publish = {
                        method: "feed",
                        name: "<?php echo $share_text_title; ?>",           // Title of your post
                        caption: "<?php echo $share_text_sub_title; ?>",    // Sub-Title of your post
                        description: ("<?php echo $share_text_description; ?>"),
                        link: "<?php echo $share_url; ?>"+id,            // Link where you want to take the users when they click on your post
                        picture: img_src_new      // Picture for your post
                        
                    };
                    
                    FB.ui(publish, function(response){

					// Check if the post was actually made or was cancelled
					if (response && !response.error_code) {
					// If post was made 
					// show thank you pop up delete 
					alert('Thank you for posting');
					} else {
					// If somehow user closed the pop up then show following pop up
					alert('Please try again later! Looks like you closed the share window or there was some error.');
					}
					// end of FB.ui
					});


                });
                <?php 
                if (!empty($entry_id) && $entry_id!==""){?>

                	$("#open_img_det").trigger("click");

                <?php }
                ?>
            	
            	<?php if (!$inside_fb){?>

            		$(".vote").find("a").on("click",function(e){
            			e.preventDefault();
            			var url_redirect = $(this).attr("href");
            			var eid = $(this).data("id2");
            			$.post ("ajax.php", {"ajax":"1","method":"redirect","eid":eid} , function (data){
            				location.replace(url_redirect);
            			});

            		});

            	<?php }?>	

            });
        </script>