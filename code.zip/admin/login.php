<?php 
session_start();
include_once("../config.php");
// Step 1 is completed now check post values of step 2 
$errors = false;
$error_text = "";

// Db Crediantials
$admin_email  = "";


if (isset($_GET['forgot'])) {
mysql_connect(DB_HOST, DB_USERNAME, DB_PASSWORD);
mysql_select_db(DB_NAME);
$admin_query = "select * from ".PREFIX."admin_login where id=1";
$admin_res = mysql_query($admin_query);
$admin_row = mysql_fetch_array($admin_res);
$admin_email = $admin_row['admin_email'];

if (isset($_GET['resetcode'])){
  // Reset Code is there we have to match it generate new password and send it via mail
if ($_GET['resetcode'] == $admin_row['resetcode']){
  // Reset code matched 
  // Generate new password and send it via email also update it in db   
$new_pass = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);
mysql_query("update admin_login set resetcode ='' , admin_password = '".md5($new_pass)."' where admin_email = '$admin_email'");
$msg = "Your Password is changed. Your new password is as follow \n Email: $admin_email \n  Password:".$new_pass;
mail($admin_email,"Password Reset Request",$msg);
$errors = true;
$error_text = "Please Check your Email for new password. Thanks.";  
}else {
$errors = true;
$error_text = "Invalid Reset Code";  
}

}else {
  // We have to mail reset link 
$reset_code = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]&resetcode=".$reset_code;
mysql_query("update ".PREFIX."admin_login set resetcode ='$reset_code' where admin_email = '$admin_email'");
$msg = "Please visit $actual_link to reset your password";
mail($admin_email,"Password Reset Request",$msg); 
$errors = true;
$error_text = "Please Check your Email for Reset Password Link.";
}



}

if (isset($_POST['admin_email'])){
// Collect values from post
$admin_email = $_POST['admin_email'];
$admin_pass = $_POST['admin_pass'];

// now check if all fields are required 
if ($admin_email == "" || $admin_pass =="" ){
  $errors = true;
  $error_text = "Please Fill in required fields";
}







if (!$errors) {

mysql_connect(DB_HOST, DB_USERNAME, DB_PASSWORD);
mysql_select_db(DB_NAME);
$query = "select * from ".PREFIX."admin_login where admin_email='".$admin_email."' and admin_password = '".md5($admin_pass)."'";
$res = mysql_query($query);
$rows=mysql_num_rows($res);

if ($rows){
  // 
  $row= mysql_fetch_array($res);
  $_SESSION['user_logged_in']=true;
  $_SESSION['user_id'] = $row['id'];
  $_SESSION['user_email'] = $row['admin_email'];
  $_SESSION['user_name'] = $row['admin_name'];
  header("Location:index.php");



}else {
  $errors = true;
  $error_text = "Invalid Username or Password";
}


}
}
mysql_connect(DB_HOST, DB_USERNAME, DB_PASSWORD);
mysql_select_db(DB_NAME);
$site_title_query = "select * from ".PREFIX."site_settings where settings_title = 'site_name'";
$site_title_res = mysql_query($site_title_query);
$site_title_row = mysql_fetch_array($site_title_res);
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login - <?php echo $site_title_row['settings_value'];?></title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="css/morris-0.4.3.min.css">
    <link rel="icon" type="image/png" href="img/favicon.png">
  </head>

  <body>

    <div id="wrapper">
        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <a class="navbar-brand" href="index.php">Log in to continue</a>
            </div>


        </nav>



      <div id="page-wrapper" class="">
        <div class="col-lg-8 well">
           <?php 
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>



          <form role="form" method="POST" action="login.php">
              <div class="form-group">
                  <label>Dummy Admin Login Details</label>
                  <p>Username: admin@admin.com</p>
                  <p>Password: welcome</p>
              </div>
 
              <div class="form-group">
                  <label>Email Address <span class="required">*</span></label>
                  <input class="form-control" placeholder="Enter email address" name="admin_email">

              </div>
              <div class="form-group">
                  <label>Password <span class="required">*</span></label>
                  <input class="form-control" placeholder="Enter password" type="password" name= "admin_pass">

              </div>


              <button type="submit" class="btn btn-primary">Submit</button>
              <a class="btn btn-default" href="?forgot=1">Forgot Password</a>
          </form>
      </div>


      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

  </body>
</html>
