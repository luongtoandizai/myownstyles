<?php 
include_once ("includes/header.php");
$total_users = $db->get_total_users_count();
$total_votes =$db->get_total_votes_count();
$total_entries =$db->get_total_entries_count();

?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Dashboard <small>Statistics Overview</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
            </ol>

          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-3">
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-6">
                                <i class="fa fa-bar-chart-o fa-5x fa-users"></i>
                            </div>
                            <div class="col-xs-6 text-right">
                                <p class="announcement-heading"><?php echo $total_users;?></p>
                                <p class="announcement-text">Total Users</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
          <div class="col-lg-3">
            <div class="panel panel-info">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa  fa-5x fa-check"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $total_votes;?></p>
                    <p class="announcement-text">Votes!</p>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-warning">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa  fa-5x fa-camera"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $total_entries;?></p>
                    <p class="announcement-text">Entries</p>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
       

        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->
<?php 
include_once ("includes/footer.php");
?>