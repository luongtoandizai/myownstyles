<?php
include_once("../config.php");
include_once("includes/header.php");
include_once("../helpers/database.php");
include_once("../helpers/functions.php");
$db = new database();
$admin_user = $db->get_admin_user_by_id($_SESSION['user_id']);
$admin_email = $admin_user ['admin_email'];
$admin_name = $admin_user ['admin_name'];
$errors = false;
$error_text = "";
$success = false;
$success_text="";

if (count($_POST)>0 && !$real_admin){
  header("Location:settings_admin.php?error=1");
  exit();
}

if (isset($_POST['admin_name'])){
// Form is posted now get required fields of name and email address
$admin_email = $_POST ['admin_email'];
$admin_name = $_POST ['admin_name'];
$admin_pass = $_POST ['admin_pass'];
$admin_repass = $_POST ['admin_repass'];

if ($admin_email == "" || $admin_name ==""){
    // Required Fields are empty 
    $errors = true;
    $error_text = "Please Fill in Required Fields.";
}

if (!$errors){
if (!validate_email_address($admin_email)){
// Email Address is not valid 
$errors = true;
$error_text = "Invalid Email Address";
}
}

if (!$errors){
if ($admin_pass !== $admin_repass){
    // Password and repasswords not matched
    $errors = true ; 
    $error_text = "Passwords not matched";
}
}


if (!$errors){
    // There are no errors now its time to update the admin 
    $db->update_admin_details($admin_email , $admin_name , $admin_pass , $_SESSION['user_id']);
    $success=true;
    $success_text="Successfuly Updated";
}



}




if (isset($_GET['error'])){
  $errors =true;
  $error_text = "Feature to Add/Update/Delete is available in full version. Thanks.";
}





?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Administrator Settings <small>Customize Administrator's Account</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-arrow-up"></i> Administrator Settings</li>
            </ol>

            <?php if ($success){?>
            <div class="alert alert-info alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $success_text;?>
            </div>
            <?php }?>
            <?php 
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
              <?php }?>
          
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-8">              
            <form role="form" method="POST">
              <div class="form-group">
                <label>Administrator's Name <span class="required">*</span></label>
                <input class="form-control" placeholder="Enter full name" name="admin_name" value="<?php echo $admin_name;?>">
                <p class="help-block">Please Provide Full Name.</p>
              </div>
              <div class="form-group">
                <label>Administrator's Email Address <span class="required">*</span></label>
                <input class="form-control" placeholder="Enter email address" name="admin_email" value="<?php echo $admin_email;?>">
                  <p class="help-block">Will be used to login.</p>
              </div>
                <div class="form-group">
                    <label>Administrator's Account Password</label>
                    <input class="form-control" placeholder="Enter password" type="password" name="admin_pass">
                    <p class="help-block">We recommend combination of alphanumeric characters.</p>
                </div>
                <div class="form-group">
                    <label>Confirm Administrator's Account Password</label>
                    <input class="form-control" placeholder="Re-type password" type="password" name="admin_repass">
                </div>
              <button type="submit" class="btn btn-primary">Submit</button>
              <button type="reset" class="btn btn-default">Reset</button>
            </form>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
    <?php include_once("includes/footer.php");?>