<?php
ob_start();
include_once("../config.php");
include_once("includes/header.php");
include_once("../helpers/database.php");
include_once("../helpers/functions.php");
$db = new database();

if ((count($_POST)>0 || isset($_GET['delete']) || isset($_GET['approve']) || isset($_GET['deapprove']) || isset($_GET['declare']) || isset($_GET['sort']) || isset($_GET['page']))  && !$real_admin){
  header("Location:users.php?error=1");
  exit();
}


if (isset($_GET['approve'])){
    if ($_GET['approve']!==""){
      // Approve parameter is there and it is not empty
      $entry_id = $_GET['approve'];
      $db->approve_entry($entry_id,1);
      header("location:users.php");
    }
}


if (isset($_POST['delete']) && $_POST['exportcsv']=="0"){

  $to_delete = $_POST['delete'];
  foreach ($to_delete as $key => $value) {
          $db->delete_user($value);
  }
  header("location:users.php");
}

if (isset($_GET['delete'])){
    if ($_GET['delete']!==""){
      // Approve parameter is there and it is not empty
      $user_id = $_GET['delete'];
      $db->delete_user($user_id);
      header("location:users.php");
    }
}



if (isset($_GET['deapprove'])){
    if ($_GET['deapprove']!==""){
      // Approve parameter is there and it is not empty
      $entry_id = $_GET['deapprove'];
      $db->approve_entry($entry_id,0);
      header("location:users.php");
    }
}

$sort_by = "";
$sort_text = "Filters";
if (isset($_GET['sort']) && $_GET['sort']!==""){
  $sort_by = $_GET['sort'];
  switch ($sort_by) {
    case '1':
      $sort_text = "Most Entries";
      break;
    case '2':
      $sort_text = "Most Votes";
      break;
    case '3':
      $sort_text = "Latest";
      break;
    case '4':
      $sort_text = "Oldest";
      break;

    default:
      # code...
      break;
  }
}

 $page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
  if ($page <= 0) $page = 1;
  $per_page = 10; // Set how many records do you want to display per page.
  $startpoint = ($page * $per_page) - $per_page;
  $statement="";

$exportcsv = false;
if (isset($_POST['exportcsv']) && $_POST['exportcsv']=="1"){
  $exportcsv = true;
}

$search_text = "";
if (isset($_POST['search_entry']) && $_POST['search_entry']!==""){
  // User has searched and its not empty 
$search_text = $_POST['search_entry'];
}


  $users = $db->get_users_details($sort_by,$statement,$per_page,$page,$url='?',$startpoint,$per_page,$search_text,$exportcsv);

$errors = false;
$error_text = "";
if (isset($_GET['error'])){
  $errors =true;
  $error_text = "Feature to Add/Update/Delete is available in full version. Thanks.";
}

?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Users</h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-users"></i> Users</li>
            </ol>
            <?php if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
              <?php }?>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <form action="users.php" method="post">
              <div class="col-lg-6">
                  <div class="btn-group">
                      <button type="button" class="btn btn-default"><?php echo $sort_text;?></button>
                      <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                          <span class="caret"></span></button>
                      <ul class="dropdown-menu">
                          <li><a href="users.php?sort=1">Most Entries</a></li>
                          <li><a href="users.php?sort=2">Most Votes</a></li>
                          <li><a href="users.php?sort=3">Latest</a></li>
                          <li><a href="users.php?sort=4">Oldest</a></li>

                      </ul>
                  </div><!-- /btn-group -->
                    <button type="button" class="btn btn-danger" onclick="javascript:export_csv1()">Delete</button>
                      <button type="button"  class="btn btn-primary" onclick="javascript:export_csv()">Export CSV</button>
                      
<input type="hidden" class="exportcsv" name="exportcsv" value="0"/>

              </div>
              <div class="col-lg-6">
                  <div class="form-group input-group">
                      <input type="text" value="<?php echo $search_text;?>" name="search_entry" class="form-control">
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button" onclick="javascript:export_csv1()"><i class="fa fa-search" ></i></button>
                </span>
                  </div>
              </div>
        <script type="text/javascript">
                        function export_csv (){ 
                         $(".exportcsv").val("1");
                         $("form").submit();
                        }
                        function export_csv1 (){ 
                         $(".exportcsv").val("0");
                         $("form").submit();
                        }
                      </script>
            <div class="table-responsive">
              <table class="table table-bordered table-hover table-striped tablesorter">
                <thead>
                  <tr>
                    <th><input type="checkbox" /> </th>
                    <th>Picture</th>
                    <th>User Name <i class="fa fa-sort"></i></th>
                    <th>Email <i class="fa fa-sort"></i></th>
                
                    <th>Phone # <i class="fa fa-sort"></i></th>
                    <th>Entered <i class="fa fa-sort"></i></th>
                    <th>Entries <i class="fa fa-sort"></i></th>
                    <th>Votes <i class="fa fa-sort"></i></th>
                    <th>Option<i class="fa"></i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  if ($users){?>
                      

                    <?php 

                    foreach ($users['entries'] as $key => $user) {

                      ?>
                   <tr>
                    <td><input  name="delete[]" value="<?php echo $user['user_id'];?>" type="checkbox"> </td>
                    <td><img src="http://graph.facebook.com/<?php echo $user['fbid'];?>/picture?type=square" width="50"> </td>
                    <td><?php echo $user['first_name']." ".$user['last_name'];?></td>
                    <td><?php
                    if ($real_admin){
                     echo $user['email'];
                   }else {
                    echo "***************";
                   }
                     ?></td>
                   
                    <td><?php echo $user['phone'];?></td>
                    <?php 
                    if ($user['entered']==0){
                      // Not Approved  / Entered yet
                      ?>
                      <td class="text-center"><a href="?approve=<?php echo $user['user_id']?>"><span class="label label-warning">No</span></a>

                    <?php }else {
                      // Approved / Entered
                      ?>
                    <td class="text-center"><a href="?deapprove=<?php echo $user['user_id']?>"><span class="label label-success">Yes</span></a>
                    <?php }
                    ?>           
                    </td>
                    <td class="text-center"><?php echo $user['entries'];?></td>
                     <td class="text-center"><?php echo $user['votes'];?> </td>
                      <td>
                          <a href="?delete=<?php echo $user['user_id'];?>"><button type="button" class="btn btn-danger btn-xs">Delete</button></a>
                      </td>
                  </tr>
                    <?php }
                    ?>
                  <?php }else {
                    ?>
                    <tr><td colspan="5" align="center"><p>No Records Found</p></td></tr>
                  <?php }
                  ?>

                  

                </tbody>
              </table>
                  </form>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
    <?php if ($users['pagination']!==""){?>


          <div class="col-sm-12 text-center">
          <?php echo $users['pagination'];?>
          </div>
          <?php }?>

        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->
      <script>

      </script>
    <?php include_once("includes/footer.php");?>