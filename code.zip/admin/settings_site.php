<?php
include_once("../config.php");
include_once("includes/header.php");
include_once("../helpers/database.php");
include_once("../helpers/functions.php");
$db = new database();
$defaul_settings = $db->get_default_settings ();
$errors = false;
$error_text= "";
$success= false;
$success_text= "";
$user_id = $_SESSION['user_id'];

if (count($_POST)>0 && !$real_admin){
  header("Location:settings_site.php?error=1");
  exit();
}

$site_name = $defaul_settings['site_name'];
$fb_secret = $defaul_settings['fb_secret'];
$fb_app_id = $defaul_settings['fb_app_id'];

$google_analytics = $defaul_settings['google_analytics'];
$facebook_link = $defaul_settings['facebook_link'];
$twitter_link = $defaul_settings['twitter_link'];
$globe_link = $defaul_settings['globe_link'];
$google_link = $defaul_settings['google_link'];
$pintrest_link = $defaul_settings['pintrest_link'];
$dots_link = $defaul_settings['dots_link'];
$youtube_link = $defaul_settings['youtube_link'];
$entries_per_user = $defaul_settings['entries_per_user'];
$terms_conditions = $defaul_settings['terms_conditions'];
$number_of_votes=   $defaul_settings['number_of_votes'];
$votes_days = $defaul_settings['votes_days'];
$start_date = $defaul_settings['start_date'];
$end_date = $defaul_settings['end_date'];
$end_date_message = $defaul_settings['end_date_message'];
$share_text_title = $defaul_settings['share_text_title'];
$share_text_sub_title = $defaul_settings['share_text_sub_title'];
$share_text_description = $defaul_settings['share_text_description'];
$admin_approval_entry = $defaul_settings['admin_approval_entry'];
$voting_choice = $defaul_settings['voting_choice'];
$favicon = $defaul_settings['favicon'];



if (isset($_POST['site_name'])){

$site_name = $_POST['site_name'];
$fb_app_id = $_POST['fb_app_id'];
$fb_secret = $_POST['fb_secret'];

$google_analytics = $_POST['google_analytics'];
$entries_per_user = $_POST['entries_per_user'];

$facebook_link = $_POST['facebook_link'];
$twitter_link = $_POST['twitter_link'];
$globe_link = $_POST['globe_link'];
$google_link = $_POST['google_link'];
$pintrest_link = $_POST['pintrest_link'];
$dots_link = $_POST['dots_link'];
$youtube_link = $_POST['youtube_link'];

$terms_conditions = $_POST['terms_conditions'];
$number_of_votes=   $_POST['number_of_votes'];
$votes_days = $_POST['votes_days'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$end_date_message = $_POST['end_date_message'];
$share_text_title = $_POST['share_text_title'];
$share_text_sub_title = $_POST['share_text_sub_title'];
$share_text_description = $_POST['share_text_description'];
$admin_approval_entry = $_POST['admin_approval_entry'];
$voting_choice = $_POST['voting_choice'];
$settings = $_POST;



if (!$errors){

// Uploading of avatar started 
if((!empty($_FILES["logo"])) && ($_FILES['logo']['error'] == 0)) {
  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['logo']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["logo"]["tmp_name"]);
  $height = $dimensions[0];
  $width = $dimensions[1];
  if (($ext == "jpg" || $ext == "JPG" || $ext == "jpeg" || $ext == "JPEG"|| $ext == "PNG"|| $ext == "png" || $ext == "GIF" || $ext == "gif")) {
    //Determine the path to which we want to save this file
      $fname=rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['logo']['tmp_name'],$newname))) {
            $settings['logo']= $fname;
        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during Logo upload!";          
        }
      } else {         
      }
  } else {
           $errors = true;
          $error_text = "Error: Invalid Logo";          
                
  }
} 
}

if (!$errors){

// Uploading of avatar started 
if((!empty($_FILES["favicon"])) && ($_FILES['favicon']['error'] == 0)){
  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['favicon']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["favicon"]["tmp_name"]);
  $height = $dimensions[0];
  $width  = $dimensions[1];
  if (($ext == "jpg" || $ext == "JPG" || $ext == "jpeg" || $ext == "JPEG"|| $ext == "PNG"|| $ext == "png" || $ext == "GIF" || $ext == "gif")) {
    //Determine the path to which we want to save this file
      $fname=rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['favicon']['tmp_name'],$newname))) {
            $settings['favicon']= $fname;
        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during favicon upload!";          
        }
      } else {         
      }
  } else {
          $errors = true;
          $error_text = "Error: Invalid favicon";                         
  }
} 
}

if (!$errors){
$banners = array();
// Uploading of avatar started 

if((!empty($_FILES["sliders"]['name'][0]))) {

for ($i=0 ; $i<count($_FILES['sliders']['name']) ; $i++){


  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['sliders']['name'][$i]);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["sliders"]["tmp_name"][$i]);
  $height = $dimensions[0];
  $width = $dimensions[1];
  if (($ext == "jpg" || $ext == "JPG" || $ext == "jpeg" || $ext == "JPEG"|| $ext == "PNG"|| $ext == "png" || $ext == "GIF" || $ext == "gif")) {
 
    //Determine the path to which we want to save this file
       $fname=rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).$filename;
      $newname = '../uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['sliders']['tmp_name'][$i],$newname))) {
            $banners[]= $fname;
        } else {
          $errors = true;
          $error_text = "Error: A problem occurred during Sliders upload!";          
        }
      } else {         
      }
  } else {
               
  }



}// for loop




if (!$errors){
  // There are no erros and all photos uploaded 
  // now save their names to databse table 
  $db->save_banners($banners);
}


} 
}



if (!$errors){
$db->update_new_settings ($settings);
$success = true;
$success_text = "Settings Updated Successfuly.";

}



}

if (isset($_GET['error'])){
  $errors =true;
  $error_text = "Feature to Add/Update/Delete is available in full version. Thanks.";
}

?>

 
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Site Settings <small>Customize Settings</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-wrench"></i> Site Settings</li>
            </ol>
            
            <?php if ($success){?>
            <div class="alert alert-info alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $success_text;?>
            </div>
            <?php }?>

            <?php 
            if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-8">

            <form role="form" method="post" enctype="multipart/form-data">

              <div class="form-group">
                <label>Site Name</label>
                <input class="form-control" name="site_name" value="<?php echo $site_name;?>">
                <p class="help-block">Name will be used in titles and email notifications etc.</p>
              </div>


              <div class="form-group">
                <label>Site Logo</label>
                <input type="file" name="logo">
                <p class="help-block">Diamensions should be 100 x 60.</p>
            </div>
            <div class="form-group">
                <label>Favicon</label>
                <input type="file" name="favicon">
                <p class="help-block">Recommended Dimensions 32x32</p>
            </div>

                <div class="form-group">
                    <label>Facebook Application ID</label>
                    <input class="form-control" name="fb_app_id" value="<?php echo $fb_app_id;?>">
                    <p class="help-block">Will be used for Log in with Facebook button.</p>
                </div>
                <div class="form-group">
                    <label>Facebook Secret</label>
                    <input class="form-control" name="fb_secret" value="<?php echo $fb_secret;?>">
                    <p class="help-block">Facebook Secret</p>
                </div>

               
              
              <div class="form-group">
                    <label>Facebook Link</label>
                    <input class="form-control" name="facebook_link" value="<?php echo $facebook_link;?>">
                    <p class="help-block">Appears at top of page</p>
              </div>
              <div class="form-group">
                    <label>Twitter Link</label>
                    <input class="form-control" name="twitter_link" value="<?php echo $twitter_link;?>">
                    <p class="help-block">Appears at top of page</p>
              </div>

          <div class="form-group">
                    <label>Google Plus Link</label>
                    <input class="form-control" name="google_link" value="<?php echo $google_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Globe Link</label>
                    <input class="form-control" name="globe_link" value="<?php echo $globe_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Pintrest Link</label>
                    <input class="form-control" name="pintrest_link" value="<?php echo $pintrest_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Dots Link</label>
                    <input class="form-control" name="dots_link" value="<?php echo $dots_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>
          <div class="form-group">
                    <label>Youtube Link</label>
                    <input class="form-control" name="youtube_link" value="<?php echo $youtube_link;?>">
                    <p class="help-block">Appears at top of page</p>
          </div>

          <div class="form-group">
                    <label>Entries Allowed per user</label>
                    <input class="form-control" name="entries_per_user" value="<?php echo $entries_per_user;?>">
                    <p class="help-block">Number of entries allowed per user</p>
          </div>
          
          <?php 
          ?>
          
          <div class="form-group">
            <label>Terms And Conditions</label>
            <textarea class="form-control" rows="3" name="terms_conditions"><?php echo $terms_conditions;?></textarea>
          </div>
          
          <div class="form-group">
                    <label>Voting limit Choice</label>
              <select name="voting_choice" class="form-control">
                <option value="1" <?php if ($voting_choice=="1"){echo 'selected="selected"';}?>>Per Photo</option>
                <option value="2" <?php if ($voting_choice=="2"){echo 'selected="selected"';}?>>Whole Contest</option>
              </select>
                    <p class="help-block">Per Photo / Per User</p>
          </div>        
              
          <div class="form-group">
                    <label>Votes (Number of votes)</label>
                    <input class="form-control" name="number_of_votes" value="<?php echo $number_of_votes;?>">
                    <p class="help-block">Number of votes </p>
          </div>

          <div class="form-group">
                    <label>Votes (days)</label>
                    <input class="form-control" name="votes_days" value="<?php echo $votes_days;?>">
                    <p class="help-block">Votes (Days)</p>
          </div>
          
          <div class="form-group">
                    <label>Start Date</label>
                    <input class="form-control start_date" name="start_date"   value="<?php echo $start_date;?>">
                    <p class="help-block">Start Date</p>
          </div>
          <div class="form-group">
                    <label>End Date</label>
                    <input class="form-control end_date" name="end_date"  value="<?php echo $end_date;?>">
                    <p class="help-block">End Date</p>
          </div>
          <div class="form-group">
                    <label>End Date Message</label>
                    <input class="form-control" name="end_date_message" value="<?php echo $end_date_message;?>">
                    <p class="help-block">End Date Message</p>
          </div>

          <div class="form-group">
                    <label>Share Text Title</label>
                    <input class="form-control" name="share_text_title" value="<?php echo $share_text_title;?>">
                    <p class="help-block">Share Text Title</p>
          </div>
          <div class="form-group">
                    <label>Share Text Sub Title</label>
                    <input class="form-control" name="share_text_sub_title" value="<?php echo $share_text_sub_title;?>">
                    <p class="help-block">Share Text Sub Title</p>
          </div>
          
            <div class="form-group">
                <label>Share Text Description</label>
                <textarea class="form-control" rows="3" name="share_text_description"><?php echo $share_text_description;?></textarea>
              </div>
              <div class="form-group">
                <label>Admin Permission To Approve Entry</label>
              <select name="admin_approval_entry" class="form-control">
                  
                <option value="1" <?php if ($admin_approval_entry=="1"){echo 'selected="selected"';}?> >Yes</option>
                <option value="0" <?php if ($admin_approval_entry=="0"){echo 'selected="selected"';}?>>No</option>
             
              </select>
              </div>

              <div class="form-group">
                      <label>Slide Banners</label>
                      <input type="file" name="sliders[]" multiple="true">
                      <p class="help-block">Appears in Front Banners</p><br/>
                  </div>


              <div class="form-group">
                <label>Google Analytics</label>
                <textarea class="form-control" rows="3" name="google_analytics"><?php echo $google_analytics;?></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary">Save</button>
              <button type="reset" class="btn btn-default">Reset</button>
            </form>
          </div>

          

        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->

    <?php include_once("includes/footer.php");?>
     <script type="text/javascript">
      jQuery(document).ready (function (){
        $( ".start_date" ).datepicker();
        $( ".end_date" ).datepicker();
      })

      </script>