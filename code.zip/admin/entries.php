<?php
ob_start();
include_once("../config.php");
include_once("includes/header.php");
include_once("../helpers/database.php");
include_once("../helpers/functions.php");
$db = new database();


if ((count($_POST)>0 || isset($_GET['delete']) || isset($_GET['approve']) || isset($_GET['deapprove']) || isset($_GET['declare']) || isset($_GET['sort']) || isset($_GET['page']))  && !$real_admin){
  header("Location:entries.php?error=1");
  exit();
}


if (isset($_POST['delete']) && $_POST['exportcsv']=="0"){
  $to_delete = $_POST['delete'];
  foreach ($to_delete as $key => $value) {
      $db->delete_entry($value);
  }
  header("location:entries.php?success=Successfully Deleted");
}



if (isset($_GET['approve'])){
    if ($_GET['approve']!==""){
      // Approve parameter is there and it is not empty
      $entry_id = $_GET['approve'];
      $db->live_entry($entry_id,1);
      header("location:entries.php?success=Successfully Approved");
    }
}

if (isset($_GET['delete'])){
    if ($_GET['delete']!==""){
      // Approve parameter is there and it is not empty
      $user_id = $_GET['delete'];
      $db->delete_entry($user_id);
      header("location:entries.php?success=Successfully Deleted");
    }
}



if (isset($_GET['deapprove'])){
    if ($_GET['deapprove']!==""){
      // Approve parameter is there and it is not empty
      $entry_id = $_GET['deapprove'];
      $db->live_entry($entry_id,0);
      header("location:entries.php?success=Successfully DeApproved");
    }
}

if (isset($_GET['declare'])){
    if ($_GET['declare']!==""){
      // Approve parameter is there and it is not empty
      $entry_id = $_GET['eid'];
      $declare = $_GET['declare'];
      
      $db->live_entry($entry_id,$declare);
      header("location:entries.php?success=Successfully Declared");
    }
}

$sort_by = "";
$sort_text = "Filters";
if (isset($_GET['sort']) && $_GET['sort']!==""){
  $sort_by = $_GET['sort'];
  switch ($sort_by) {
    case '1':
      $sort_text = "Allowed";
      break;
    case '2':
      $sort_text = "Pending Review";
      break;
    case '3':
      $sort_text = "Most Votes";
      break;
    case '4':
      $sort_text = "Latest";
      break;
     case '5':
      $sort_text = "Oldest";
      break; 

    default:
      # code...
      break;
  }
}
$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
if ($page <= 0) $page = 1;
$per_page = 5; // Set how many records do you want to display per page.
$startpoint = ($page * $per_page) - $per_page;
$statement="";

$exportcsv = false;
if (isset($_POST['exportcsv']) && $_POST['exportcsv']=="1"){
  $exportcsv = true;
}

$search_text = "";
if (isset($_POST['search_entry']) && $_POST['search_entry']!==""){
  // User has searched and its not empty 
$search_text = $_POST['search_entry'];
}

$entries = $db->get_entries_all($sort_by,$statement,$per_page,$page,$url='?',$startpoint,$per_page,$search_text,$exportcsv);
$first = false;
$second = false;
$third = false;
$errors = false;
$error_text = "";
if (isset($_GET['error'])){
  $errors =true;
  $error_text = "Feature to Add/Update/Delete is available in full version. Thanks.";
}
?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Entries</h1>
            <ol class="breadcrumb">
              <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-users"></i> Entries</li>
            </ol>
            <?php if ($errors){
            ?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
              <?php }?>

            <?php if (isset($_GET['success'])){?>
            <div class="alert alert-info alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $_GET['success'];?>
            </div>
            <?php }?> 

          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
              <form method="post" action="entries.php">
              <div class="col-lg-6">
          
                  <div class="btn-group">
                      <button type="button" class="btn btn-default"><?php echo $sort_text;?></button>
                      <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                          <span class="caret"></span></button>
                      <ul class="dropdown-menu">
                          <li><a href="entries.php?sort=1">Allowed</a></li>
                          <li><a href="entries.php?sort=2">Pending Review</a></li>
                          <li><a href="entries.php?sort=3">Most Votes</a></li>
                          <li><a href="entries.php?sort=4">Latest</a></li>
                          <li><a href="entries.php?sort=5">Oldest</a></li>

                      </ul>
                  </div><!-- /btn-group -->
                      <button type="button" class="btn btn-danger" onclick="javascript:export_csv1()">Delete</button>
                      <button type="button"  class="btn btn-primary" onclick="javascript:export_csv()">Export CSV</button>
                      
              </div>
              <input type="hidden" class="exportcsv" name="exportcsv" value="0"/>
              <div class="col-lg-6">
                  <div class="form-group input-group">
                      <input type="text" value="<?php echo $search_text;?>" name="search_entry" class="form-control">
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button" onclick="javascript:export_csv1()"><i class="fa fa-search"></i></button>
                </span>
                  </div>
              </div>
              <!-- Form Ends here -->
              <script type="text/javascript">
                        function export_csv (){ 
                         $(".exportcsv").val("1");
                         $("form").submit();
                        }
                         function export_csv1 (){ 
                         $(".exportcsv").val("0");
                         $("form").submit();
                        }
                      </script>
            <div class="table-responsive">
              <table class="table table-bordered table-hover table-striped tablesorter">
                <thead>
                  <tr>
                    <th><input type="checkbox" /> </th>
                    <th>Entry</th>
                    <th>By <i class="fa fa-sort"></i></th>
                    <th>Email <i class="fa fa-sort"></i></th>
                    <th>Status <i class="fa fa-sort"></i></th>
                    <th>Votes <i class="fa fa-sort"></i></th>
                    <th>Option<i class="fa"></i></th>
                  </tr>
                </thead>
                <tbody>

  <?php 
                  if ($entries){?>
                                        

                    <?php 
                    foreach ($entries['entries'] as $key1 => $user1) {
                      if ($user1['approved']==-1){
                        $first = true;
                      }
                      if ($user1['approved']==-2){
                        $second = true;
                      }
                      if ($user1['approved']==-3){
                        $third = true;
                      }
                    
                    }


                    foreach ($entries['entries'] as $key => $user) {
                      
                      
                      ?>


                  <tr>
                    <td><input name="delete[]" value="<?php echo $user['id'];?>" type="checkbox"> </td>
                    <td><img style="cursor: pointer;" class="enlarge" src="../uploads/<?php echo $user['photo'];?>" width="50"> </td>
                    <td><?php echo $user['first_name']." ".$user['last_name'];?></td>
                    <td><?php echo $user['email'];?></td>
                    <?php
                    if ($user['approved'] == "1"){?>
                    <td class="text-center"><span class="label label-success">Live</span>

                    <?php }else {?>
                    <td class="text-center"><span class="label label-warning">Pending</span>

                    <?php }
                    ?>
                      
                    </td>
                    <td class="text-center"><?php echo $user['votes'];?></td>
                      <td>
                          <div class="btn-group">
                              <button type="button" class="btn btn-default btn-xs">
                                <?php 
                                if ($user['approved']==-1){
                                  echo "Declared 1st";
                                }elseif ($user['approved']==-2){
                                  echo "Declared 2nd";
                                }elseif ($user['approved']==-3){
                                  echo "Declared 3rd";
                                }else if($user['approved']==1){
                                  echo "Approved";
                                }else if($user['approved']==0){
                                  echo "Pending";
                                }



                                ?>
                              </button>
                              <button type="button" class="btn btn-default dropdown-toggle btn-xs" data-toggle="dropdown">
                                  <span class="caret"></span></button>
                              <ul class="dropdown-menu ">
                                  <?php if ($user['approved']=="0"){?>
                                    <li><a href="?approve=<?php echo $user['id'];?>">Approve</a></li>
                                  <?php }else{?>
                                     <li><a href="?deapprove=<?php echo $user['id'];?>">De Approve</a></li>
                                  <?php }?>
                                  
                                  <li><a href="?delete=<?php echo $user['id'];?>">Delete</a></li>
                                  <li class="divider"></li>
                                  
                                  <?php 
                                  if (!$first){
                                  ?>
                                   <li><a href="entries.php?declare=-1&eid=<?php echo $user['id'];?>">Declare 1st</a></li>
                                 
                                  <?php }?>

                                  <?php 
                                  if (!$second){
                                  ?>
                                   <li><a href="entries.php?declare=-2&eid=<?php echo $user['id'];?>">Declare 2nd</a></li>
                                 
                                  <?php }?>

                                  <?php 
                                  if (!$third){
                                  ?>
                                  <li><a href="entries.php?declare=-3&eid=<?php echo $user['id'];?>">Declare 3rd</a></li>
                              
                                  <?php }?>
                                 
                              </ul>
                          </div><!-- /btn-group -->
                      </td>
                  </tr>


                   
                    <?php }
                    ?>
                  <?php }else {
                    ?>
                    <tr><td colspan="5" align="center"><p>No Records Found</p></td></tr>
                  <?php }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <?php if ($entries['pagination']!==""){?>


          <div class="col-sm-12 text-center">
          <?php echo $entries['pagination'];?>
          </div>
          <?php }?>

        
        </div><!-- /.row -->



      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

    <script type="text/javascript">
    $(document).ready (function(){
   $('.enlarge').on('click',function(){
                var src = $(this).attr('src');
                var img = '<img src="' + src + '" class="img-responsive"/>';
                $('#picenlarge').modal();
                $('#picenlarge').on('shown.bs.modal', function(){
                    $('#picenlarge .modal-body').html(img);
                });
                // $("#close_btn").on("click",function(){
                //    $('#picenlarge').modal("hide");
                // });

                $('#picenlarge').on('hidden.bs.modal', function(){
                    $('#picenlarge .modal-body').html('');
                });
           });  
    });

    </script>
<div class="modal fade" id="picenlarge" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">         
          <div class="modal-body">                
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  </body>
</html>