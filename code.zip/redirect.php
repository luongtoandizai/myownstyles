<?php 
include_once("config.php");
include_once ("helpers/language.php");
include_once ("helpers/database.php");
$db = new database();
if(session_id() == '') {
    session_start();
}
function isMobile() {
    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}
$settings_app_id = $db ->get_settings_by_setting_name("fb_app_id");
$app_id = $settings_app_id['settings_value'];
$settings_fan_page_url = $db ->get_settings_by_setting_name("fan_page_url");
$settings_site_url = $db ->get_settings_by_setting_name("main_site_url");
$fan_page_url = $settings_fan_page_url['settings_value'];
$main_site_url = $settings_site_url['settings_value'];
$redirect_to_website = str_replace("redirect.php", "index.php", $main_site_url);	

if (isset($_GET['platform']) && isset($_GET['app_data'])){
	// platform and app data available
	$platform = $_GET['platform'];
	$app_data = $_GET['app_data'];
	$redirect_url ="";	
	switch ($platform) {
		case 'canvas':
			$redirect_url = "https://apps.facebook.com/".$app_id."/?app_data=".$app_data;
			break;
		case 'fanpage':
			if (isMobile()){
				// Visited from Mobile
			$redirect_url = $redirect_to_website."?app_data=".$app_data;	
			}else{
				// Visit from Desktop
				$redirect_url = $fan_page_url."&app_data=".$app_data;
			}
			
			break;
		case 'website':
			$redirect_url = $redirect_to_website."?app_data=".$app_data;
			break;	
		default:
			# code...
			break;
	}
header("Location:".$redirect_url);
}else{
	echo "No Direct Access";
	die ();
}



?>