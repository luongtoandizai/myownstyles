<?php 
include_once("config.php");
include_once ("helpers/database.php");
$db = new database();
?>