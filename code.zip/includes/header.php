<?php
//session_start();
//ob_start();
?>
<?php 

include_once("config.php");
include_once ("helpers/language.php");
include_once ("helpers/database.php");
$db = new database();
$enter_contest_url = "enter-contest.php";
$fb_logged_in = true;
$logo_res=$db->get_settings_by_setting_name("logo");
$site_title_res = $db->get_settings_by_setting_name("site_name");
$facebook_link = $db->get_settings_by_setting_name("facebook_link");
$twitter_link = $db->get_settings_by_setting_name("twitter_link");
$globe_link = $db->get_settings_by_setting_name("globe_link");
$google_link = $db->get_settings_by_setting_name("google_link");
$pintrest_link = $db->get_settings_by_setting_name("pintrest_link");
$dots_link = $db->get_settings_by_setting_name("dots_link");
$youtube_link = $db->get_settings_by_setting_name("youtube_link");
$favicon = $db->get_settings_by_setting_name("favicon");
// include required files form Facebook SDK
require_once( 'Facebook/HttpClients/FacebookHttpable.php' );
require_once( 'Facebook/HttpClients/FacebookCurl.php' );
require_once( 'Facebook/HttpClients/FacebookCurlHttpClient.php' );

require_once( 'Facebook/Entities/AccessToken.php' );
require_once( 'Facebook/Entities/SignedRequest.php' );

require_once( 'Facebook/FacebookSession.php' );
require_once( 'Facebook/FacebookRedirectLoginHelper.php' );
require_once( 'Facebook/FacebookSignedRequestFromInputHelper.php' );
require_once( 'Facebook/FacebookRequest.php' );
require_once( 'Facebook/FacebookResponse.php' );
require_once( 'Facebook/FacebookSDKException.php' );
require_once( 'Facebook/FacebookRequestException.php' );
require_once( 'Facebook/FacebookOtherException.php' );
require_once( 'Facebook/FacebookAuthorizationException.php' );

// these two classes required for canvas and tab apps
require_once( 'Facebook/FacebookCanvasLoginHelper.php' );
require_once( 'Facebook/FacebookPageTabHelper.php' );

require_once( 'Facebook/GraphObject.php' );
require_once( 'Facebook/GraphSessionInfo.php' );

use Facebook\HttpClients\FacebookHttpable;
use Facebook\HttpClients\FacebookCurl;
use Facebook\HttpClients\FacebookCurlHttpClient;

use Facebook\Entities\AccessToken;
use Facebook\Entities\SignedRequest;

use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookSignedRequestFromInputHelper; // added in v4.0.9
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookOtherException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\GraphSessionInfo;

// these two classes required for canvas and tab apps
use Facebook\FacebookCanvasLoginHelper;
use Facebook\FacebookPageTabHelper;


if(session_id() == '') {
    session_start();
}

$page_to_show=false;
$settings_app_id = $db ->get_settings_by_setting_name("fb_app_id");
$settings_app_secret = $db ->get_settings_by_setting_name("fb_secret");
$settings_fan_page_url = $db ->get_settings_by_setting_name("fan_page_url");
$settings_site_url = $db ->get_settings_by_setting_name("main_site_url");
$fan_page_url = $settings_fan_page_url['settings_value'];
$main_site_url = $settings_site_url['settings_value'];


$app_id = $settings_app_id['settings_value'];
$app_secret = $settings_app_secret['settings_value'];
if ($app_id=="" || $app_secret==""){
	// App Secret or app id is not set. ask to set it in admin pannel 
	echo "Application id or application secret is not set.";
	$page_to_show = false;
}else {
	// Appid and secret is given


header('P3P: CP="CAO PSA OUR"');
// start session


// init app with app id and secret
FacebookSession::setDefaultApplication($app_id,$app_secret);

// init page tab helper
$pageHelper = new FacebookPageTabHelper();

// get session from the page
$session = $pageHelper->getSession();


//$page_url = "";
$page_id= $pageHelper->getPageId();
//echo $page_id;



$redirect_array = array ();
$redirect_array['redirect'] ='1';
$redirect_array['custom_data'] ='dummy';


if ($page_id){
$app_id  = FacebookSession::_getTargetAppId();
//echo  " <br>app is=<br> " . $app_id;
$page_info = json_decode(file_get_contents("https://graph.facebook.com/{$page_id}?fields=link&access_token={$app_id}|{$app_secret}"));


$page_url= $page_info->link;
$page_url.="?sk=app_" . $app_id."&app_data=".json_encode($redirect_array);
if ($fan_page_url ==""){
	$new_settings_fan_page = array ();
	$new_settings_fan_page['fan_page_url'] =$page_url;
	$db->update_new_settings($new_settings_fan_page); 
}
$_SESSION["pageurl"] = $page_url;
}
//echo $_SESSION["pageurl"];

$access_type = "";
if (isset($_REQUEST['signed_request'])){
	// App is accessed inside canvas
	$_SESSION['signed_request'] = $_REQUEST['signed_request'];	
	// It is accesed in fb 
	$signed_request = $_REQUEST['signed_request'];
	$data_signed_request = explode('.',$signed_request); // Get the part of the signed_request we need.
	$jsonData = base64_decode($data_signed_request['1']); // Base64 Decode signed_request making it JSON.
	$objData = json_decode($jsonData,true); // Split the JSON into arrays.
	$pageData = $objData['page'];
	if ($pageData){

	}else{
		// It is canvas App 
		$_SESSION['pageurl'] = "https://apps.facebook.com/".$app_id."/?app_data=".json_encode($redirect_array);

	}
	$inside_fb = true;
}else{

	if (!isset($_SESSION['signed_request'])){
		// This app is accesed outside fb
		$current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		if (strpos($current_url,"?") !== false) {
		    // string contains the ? 
		$current_url= substr($current_url, 0, strrpos($current_url, "?"));
		}
		if ($main_site_url ==""){
		$current_site_url = str_replace("index.php", "", $current_url);	
		$current_site_url = str_replace("gallery.php", "", $current_site_url);

		$new_settings_site_url = array ();
		$new_settings_site_url['main_site_url'] =$current_site_url."redirect.php";
		$db->update_new_settings($new_settings_site_url); 
		}	

		$_SESSION['pageurl'] = $current_url."?redirect=1&custom_data=dummy";

		}else{
			// It is accessed inside fb but in inner page 
		$inside_fb = true;
		}
	}


 $path = pathinfo($current_url);
 $gallery_path =  $path['dirname'];
 $helper = new FacebookRedirectLoginHelper($_SESSION["pageurl"]);


if ( isset( $_SESSION ) && isset( $_SESSION['fb_token'] ) ) {
    // create new session from saved access_token
    $session = new FacebookSession( $_SESSION['fb_token'] );
    
    // validate the access_token to make sure it's still valid
    try {
        if ( !$session->validate() ) {
            $session = null;
        }
    } catch ( Exception $e ) {
        // catch any exceptions
        $session = null;
    }

}

if ( !isset( $session ) || $session === null ) {
    // no session exists

    try {

    $session = $helper->getSessionFromRedirect();

    } catch( FacebookRequestException $ex ) {
        // When Facebook returns an error
        // handle this better in production code
        print_r( $ex );
    } catch( Exception $ex ) {
        // When validation fails or other local issues
        // handle this better in production code
        print_r( $ex );
    }

}


// If we have a session
if ( isset( $session ) ) {
    // save the session
    $_SESSION['fb_token'] = $session->getToken();
    $session = new FacebookSession($_SESSION['fb_token']);
	$user =get_user_data($session);
	$_SESSION['user'] = $user;
	$first_name = $user->getProperty('first_name');
    $last_name = $user->getProperty("last_name");
    $email = $user->getProperty ("email");
    $fbid = $user->getProperty ("id");

    $user_array = array ();
    $user_array['first_name'] = $first_name;
    $user_array['last_name'] = $last_name;
    $user_array['email'] = $email;
    $user_array['fbid'] = $fbid;
    $user_id=$db->save_user($user_array);
    $_SESSION['userid'] = $user_id;
    $_SESSION['useremail'] = $email;
    } else {
    //echo "session not set";
    if (isset($_SESSION['fb_token'])){
    	unset($_SESSION['fb_token']);
    	header("Location:index.php");
    }	
    $redirect_login = $helper->getLoginUrl(array('email'));
    $enter_contest_url = $redirect_login;	
   	$fb_logged_in = false;

}

}


function get_user_data($session){

    // graph api request for user data
    $request = new FacebookRequest( $session, 'GET', '/me' );
    $response = $request->execute();
    // get response
    $graphObject = $response->getGraphObject();
    // print profile data
     //echo '<pre>' . print_r( $graphObject, 1 ) . '</pre>';
    // echo $id = $graphObject->getProperty('id');
    return $graphObject;
}

function share_facebook($settings){
    $session = new FacebookSession($_SESSION['fb_token']);
   	global $db;
	 $settings_share_text_title = $db->get_settings_by_setting_name("share_text_title");
    $settings_share_text_description = $db->get_settings_by_setting_name("share_text_description");
  	
     try {
        $request = new FacebookRequest(
            $session,
            'POST',
            '/me/feed',
            array (
                'message' => $settings_share_text_title['settings_value'],
                'link'=> "$gallery_path/uploads/".$settings['photo'],
                'description' => $settings_share_text_description['settings_value']
            )
        );
        
        $response = $request->execute();
        $graphObject = $response->getGraphObject()->asArray();

    } catch(FacebookSDKException $e) {
        echo 'Error Publishing to Facebook: ' . $e->getMessage();
        exit;
    }
    /* handle the result */
    

}

$login_redirect = false;
if (isset($_REQUEST['signed_request'])) {
		$signed_request = $_REQUEST['signed_request'];	
		$data_signed_request = explode('.',$signed_request); // Get the part of the signed_request we need.
	  $jsonData = base64_decode($data_signed_request['1']); // Base64 Decode signed_request making it JSON.
	  $objData = json_decode($jsonData,true); // Split the JSON into arrays.
	  $pageData = $objData['page'];

	  $liked = $pageData['liked']; //you have the liked boolean
	  $sourceData = $objData['app_data']; // yay you got the damn data in an string, slow clap for you

	  $entry_id = false;
	  if (!empty($sourceData)){
	  	$returned_array = json_decode($sourceData);	  	
	  	if ($returned_array->redirect){
	  	if ($returned_array->redirect=='1'){
	  		if ($returned_array->custom_data!=="dummy"){
	  			// Not Dummy
	  		$entry_id = $returned_array->custom_data;
	  		}else{
	  			// Dummy
	  		header("Location:enter-contest.php");
		die ();
	  		}
	  	}
	  }



	  }else{
	  	if (isset($_GET['app_data'])){
		$returned_array = json_decode($_GET['app_data']);
		if ($returned_array->redirect=='1'){
	  		if ($returned_array->custom_data!=="dummy"){
	  			// Not Dummy
	  		$entry_id = $returned_array->custom_data;
	  		}else{
	  			// Dummy
	  		header("Location:enter-contest.php");
		die ();
	  		}
	  	}
	  }
	  }	
	}else{

		
		
	  }
	



if (isset($_GET['redirect']) && !$inside_fb){

	if ($_GET['redirect']==1){
		if (isset($_GET['custom_data'])){
			
			if (isset($_SESSION['eid'])){
			$eid = $_SESSION['eid'];	
			unset($_SESSION['eid']);
			header("Location:index.php?app_data=".$eid);
			die ();
			}else{
			header("Location:enter-contest.php");
			die ();		
			}

			
		}else{
		header("Location:enter-contest.php");
		die ();
		}
	}
}

?>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <title><?php echo $site_title_res['settings_value'];?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <!--  Favicon.ico -->
		
		<link rel="shortcut icon" type="image/x-icon" href="./uploads/<?php echo $favicon['settings_value'];?>" />
		<link rel="apple-touch-icon" href="apple-touch-icon-precomposed.png" />
		
		<!--  Fonts  CSS. -->
		
		<link rel="stylesheet" href="fonts/font-awesome.min.css">
		<link href='//fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
	    <link href='//fonts.googleapis.com/css?family=Pontano+Sans' rel='stylesheet' type='text/css'>
		<!--  Boostrap  CSS. -->
		
		<link rel="stylesheet" href="css/bootstrap.css">
				
		<!--  Reset CSS. -->
		
		<link rel="stylesheet" href="css/normalize.css">
		
		<!--  Style CSS. -->
        
        <link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all" />
		
		<!--  Mordanizr CSS. -->
		
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
		
        <!--[if gte IE 9]
			<style type="text/css">
			.gradient {
			filter: none;
			}
			</style>
		<![endif]-->
		
    </head>
    <body>
    <!-- fb-root is required div to load Facebook JS SDK on the page. Do not delete it -->
    <div id="fb-root"></div>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
<!-- Site contents strat here-->
		<div class="fix main-warp">
	<!--Mother Header Are -->
		<header id="header">
			<div class="fix container">
				<div class="fix row">
				
					<div class="fix col-sm-12">
					
						<div class="fix navbar-brand">
							<?php 
							if ($logo_res){
								if ($logo_res['settings_value']!==""){?>
								<img src="./uploads/<?php echo $logo_res['settings_value'];?>" alt="" />
								<?php }else {?>
								<img src="./img/logo.png" alt="" />
								<?php }
							}else {?>
							<img src="./img/logo.png" alt="" />
							<?php }
							?>
						</div>
						<div class="fix social-icons pull-right">
							<ul>
								<?php if ($twitter_link['settings_value']!==""){?>
								<li><a href="<?php echo $twitter_link['settings_value'];?>"><i class=" fa fa-twitter-square"></i></a></li>
								<?php }?>	
									<?php if ($facebook_link['settings_value']!==""){?>
							
								<li><a href="<?php echo $facebook_link['settings_value'];?>"><i class=" fa fa-facebook-square"></i></a></li>
								<?php }?>	
							
								<?php if ($google_link['settings_value']!==""){?>
								
								<li><a href="<?php echo $google_link['settings_value'];?>"><i class=" fa fa-google-plus-square"></i></a></li>
								<?php }?>	
							
								<?php if ($globe_link['settings_value']!==""){?>
								
								<li><a href="<?php echo $globe_link['settings_value'];?>"><i class=" fa fa-dribbble"></i></a></li>
								<?php }?>	
							
								<?php if ($pintrest_link['settings_value']!==""){?>
								
								<li><a href="<?php echo $pintrest_link['settings_value']; ?>"><i class=" fa fa-pinterest-square"></i></a></li>
								<?php }?>	
							
								<?php if ($dots_link['settings_value']!==""){?>
								
								<li><a href="<?php echo $dots_link['settings_value'];?>"><i class=" fa fa-flickr"></i></a></li>
								<?php }?>	
							
								<?php if ($youtube_link['settings_value']!==""){?>
								
								<li><a href="<?php echo $youtube_link['settings_value'];?>"><i class=" fa fa-youtube-square"></i></a></li>
								<?php }?>	
							
							</ul>
						</div>
						
					</div>
					
				</div>
			</div>
		</header>
		
	<!-- /.Mother Header Are -->
		
		<div class="clearfix"></div> 
		
	<!--Mother Navigation Are -->
		
		<nav class="fix navbar navbar-default" role="navigation">
		  <div class="fix container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
				<span class=" sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>
			<?php 
				$page = basename($_SERVER['PHP_SELF']);
				$class_home = "";
				$class_enter_now = "";
				$class_rules = "";
				$class_gallery = "";
				if ($page=="index.php"){
					$class_home ="class='active'";
				}
				if ($page=="gallery.php"){
					$class_gallery ="class='active'";
				}
				if ($page=="enter-contest.php"){
					$class_enter_now ="class='active'";
				}
				if ($page=="rules.php"){
					$class_rules ="class='active'";
				}
			?>

			<!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="navbar-collapse">
                  <ul class="nav navbar-nav">
                      <li <?php echo $class_home;?> ><a href="index.php"><?php echo $lang_home_header_text;?></a></li>
                      <li <?php echo $class_gallery;?>><a href="gallery.php"><?php echo $lang_gallery_header_text;?></a></li>
                      <?php if ($fb_logged_in){
								$target ="";
							}else {
								$target ='target="_top"';
							}?>
                      <li <?php echo $class_enter_now;?>><a  href="<?php echo $enter_contest_url;?>" <?php echo $target;?> ><?php echo $lang_enter_now_header_text;?></a></li>
                      <li <?php echo $class_rules;?>><a href="rules.php"><?php echo $lang_rules_header_text;?></a></li>
                  </ul>

              </div><!-- /.navbar-collapse -->
		  </div><!-- /.container-fluid -->
		</nav>
	<!-- /.Mother Navigation Are -->

		<div class="clearfix"></div> 
		
	<!--Photo Contest  page 2 Are -->
