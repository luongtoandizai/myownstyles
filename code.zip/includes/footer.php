<!-- Mother Footer Are -->
		<div class="border-bg"></div>
		<footer id="footer">
			<div class=" container">
				<div class=" row">
					<div class=" col-sm-12">
						<div class="footer pull-left">
							<p> <?php echo $lang_footer_text;?></p>
						</div>
					</div>
				</div>
			</div>
		</footer>
		
	<!-- /.Mother Footer Are -->
		</div>
 <!-- Site contents End here-->

 
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
		<script src="js/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->

            <?php
            $settings_google_analytics = $db->get_settings_by_setting_name("google_analytics");
            echo $settings_google_analytics['settings_value'];?>

        <script type="text/javascript">
            // Function to load / setup SDK
            window.fbAsyncInit = function() {
                // FB.init is method used to initialize and setup the SDK
                FB.init({
                    appId      : '<?php echo $app_id?>', // Enter your App Id where which you get from your apps dashboard
                    xfbml      : true, // To render social plugin this has to be true, in this page we are using like button
                    version    : 'v2.0' // Latest version of SDK
                });
                // Used to grow your iframe to fit the content every
                FB.Canvas.setAutoGrow();

               
            };

            // Load the SDK Asynchronously
            (function(d){
                var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
                js = d.createElement('script'); js.id = id; js.async = true;
                js.src = "//connect.facebook.net/en_US/all.js";
                d.getElementsByTagName('head')[0].appendChild(js);
            }(document));
            
        </script>
    </body>
</html>
