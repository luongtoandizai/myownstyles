<?php
if (file_exists(__DIR__."/config.php")){
}else {
	// Setup is not installed yet
	header("Location: setup");
}
	include_once ("includes/header.php");
		$terms_conditions = $db->get_settings_by_setting_name("terms_conditions");
		$terms_conditions_text = $terms_conditions['settings_value']; 	
?>	
		<section id="page-trams">
			<div class="fix container">
				<div class="fix row">
					<h1>Terms and Conditions</h1>
					<div class="border-bg"></div>
					<div class="fix col-sm-12">
						<div class="fix trams">
							<?php 
							if ($terms_conditions_text == ""){
								echo "<p>No Text Found You Can Add that Text in Admin Site Settings.</p>";
							}else {
							echo $terms_conditions_text;
							}
							?>
						</div>
					</div>
					
					
					
					
				</div>
			</div>
		</section>
	<!-- /.Enter page Are -->
	
	<div class="clearfix"></div>
		
		<?php include_once ("includes/footer.php");?>