<?php
if (file_exists(__DIR__."/config.php")){
}else {
	// Setup is not installed yet
	header("Location: setup");
}
ob_start();
session_start();
$page_to_show = false;

include("includes/header.php");
	$start_date = "";
	$end_date = "";
	$settings_start = $db->get_settings_by_setting_name("start_date");
	$settings_end = $db->get_settings_by_setting_name("end_date");
	$start_date = $settings_start['settings_value'];
	$end_date = $settings_end ['settings_value'];
	
    
	if ($start_date == "" || $end_date == ""){
		// Contest start and end didnt configured yet
		echo "Contest is not started yet. Please Configure Start and End of Contest"; 
	}else {
		// Contest is configured 
		$paymentDate = date('Y-m-d');
    $paymentDate=date('Y-m-d', strtotime($paymentDate));;
    //echo $paymentDate; // echos today! 
    $contractDateBegin = date('Y-m-d', strtotime($start_date));
    $contractDateEnd = date('Y-m-d', strtotime($end_date));
    if (($paymentDate > $contractDateBegin) && ($paymentDate < $contractDateEnd))
    {
      $page_to_show = true;
    }
    else
    {
    	if ($paymentDate < $contractDateEnd){
    		echo $lang_contest_not_started;
    	}else {
    		echo $lang_contest_over;		
    	}
      
    }
	}
	


	// initialize the variables 

	
	$success = false;
	$success_message = "";
	$errors = false;
	$error_text = "";

	$first_name = "";
	$last_name = "";
	$email = "";
	$phone ="";
	$fbid="";
	if (isset($_POST['first_name'])){

		// form is posted 
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$fbid = $_POST['fbid'];
	// now check the required fieds 
	$settings = $_POST;
	$settings['photo']="";
	if ($first_name == "" || $last_name == "" || $email == "" ){
		$errors = true;
		$error_text = $language_fill_all_fields;
	}

	if (!$errors && $phone!==""){
		if (!is_numeric ($phone)){
			$errors = true;
			$error_text = $language_invalid_phone_number;
		}

	}
	
	if (!$errors){
		if (filter_var($email, FILTER_VALIDATE_EMAIL)){
		  // Email is valid
		}else {
		// Email is not valid 
		  $errors = true;
		  $error_text = $language_invalid_email_address;
		}

	}

	// if (!$errors){
	// 	 $db->check_existing_email_address($email);
	// }

if (!$errors){
if (empty($_FILES["photo"]['name'])){
	$errors = true;
	$error_text = $language_photo_required;
}

}



	if (!$errors){	
// Uploading of avatar started 
if((!empty($_FILES["photo"])) && ($_FILES['photo']['error'] == 0)) {
  //Check if the file is JPEG image and it's size is less than 350Kb
  $filename = basename($_FILES['photo']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);

  $dimensions = getimagesize($_FILES["photo"]["tmp_name"]);
  $height = $dimensions[0];
  $width = $dimensions[1];
   if (($ext == "jpg" || $ext == "JPG" || $ext == "jpeg" || $ext == "JPEG"|| $ext == "PNG"|| $ext == "png" || $ext == "GIF" || $ext == "gif")) {
 
    //Determine the path to which we want to save this file
       $fname=rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).rand(5, 15).$filename;
      $newname = 'uploads/'.$fname;
      //Check if the file with the same name is already exists on the server
      if (!file_exists($newname)) {
        //Attempt to move the uploaded file to it's new place
        if ((move_uploaded_file($_FILES['photo']['tmp_name'],$newname))) {
            $settings['photo']= $fname;
        } else {
          $errors = true;
          $error_text = $language_error_uploading_photo;          
        }
      } else {         
      }
  } else {
           $errors = true;
          $error_text = $language_error_invalid_photo;          
                
  }
} 
}




	if (!$errors){	

		$admin_approval_entry_settings = $db->get_settings_by_setting_name("admin_approval_entry");
		$admin_approval_entry = $admin_approval_entry_settings['settings_value'];

		$approval = "";

		if ($admin_approval_entry == "1"){
			$approval = "0";
		}else {
			$approval = "1";
		}

		if ($db->save_contest($settings,$approval)){
			// Entry Saved
			 
			$success = true;
			if ($admin_approval_entry=="1"){
			$success_message = $language_entry_sent_admin_approval;
			}else {
			$success_message = $language_entry_displayed_on_gallery;
			}
		}else {
			$errors = true;
			$error_text = $language_maximum_entry_limit_reached;
		}

	}

	}
    
    $user =$_SESSION['user'];
    $first_name = $user->getProperty('first_name');
    $last_name = $user->getProperty("last_name");
    $email = $user->getProperty ("email");
    $fbid = $user->getProperty ("id");
    

?>	
<?php if ($page_to_show){?>
	<!--Enter page Are -->
	<script type="text/javascript">
		
		function test (){
			document.getElementById('submit_form_button').innerHTML='<h2>Please Wait ....!</h2>';
					
		}
	

		</script>
		<section id="page-enter">
			<div class="fix container">
				<div class="fix row">
					<h1><?php echo $lang_heading_enter_contest_text;?></h1>
					<div class="border-bg"></div>
					<div class="fix col-sm-6">
						<div class="fix enter-entry">
						 <form name="myform" onsubmit="javascript: test ()" id="myform" role="form" method="post" enctype="multipart/form-data">
						 <?php if ($success){?>
				            <div class="alert alert-info alert-dismissable">
				              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				                <?php echo $success_message;?>
				            </div>
            			<?php }?>


						<?php  
						if ($errors){
            			?>
              <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <?php echo $error_text;?>
              </div>
          <?php }?>
							<ul>
								<li><?php echo $lang_first_name_text;?>
									<input type="text" name="first_name" readonly="readonly"   placeholder="First Name" value="<?php echo $first_name;?>">
								</li>
								
								<li><?php echo $lang_last_name_text;?>
								<input type="text" name="last_name" readonly="readonly"  placeholder="Last Name" value="<?php echo $last_name;?>">
								</li>
								
								<li><?php echo $lang_email_address_text;?>
								<input type="email" name="email" readonly="readonly"  placeholder="Email Address" value="<?php echo $email;?>">
								</li>
								
								<li><?php echo $lang_phone_number_text;?>
									<input type="text" name="phone"  placeholder="Phone Number" value="<?php echo $phone;?>">
								</li>
								<input type="hidden" name="fbid" value="<?php echo $fbid;?>"/>
								<li><?php echo $lang_upload_photo_text;?>
									<input type="file" name="photo" id="file-upload"/>
								</li>
								
								<!-- <li>Share on Facebook
									<input type="checkbox" name="share_facebook" value="1" id="checkbox" />
								</li>
								 -->
								
								<li id="submit_form_button"><input type="submit"  value="<?php echo $lang_submit_button_enter_contest;?>" id="submit"  /></li>
							</ul>
							</form> 
						</div>
					</div>
					<div class="fix col-sm-6">
						<div class="fix enter-instruct">
							<h2><?php echo $lang_heading_blue_box;?></h2>
							<ul>
								<li><?php echo $lang_instruction_first_text;?></li>
								<li><?php echo $lang_instruction_second_text;?></li>
								<li><?php echo $lang_instruction_third_text;?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<?php } ?>
		<div class="border-bg"></div>
		


	<!-- /.Enter page Are -->
	
	<div class="clearfix"></div>
		<?php include_once ("includes/footer.php");?>