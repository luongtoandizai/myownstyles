<?php 
if (file_exists(__DIR__."/config.php")){
}else {
	// Setup is not installed yet
	header("Location: setup");
}
	include_once("includes/header.php");
    // $page_url=$_GET["page_url"];
    // echo "pageurl" . $page_url;
	$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
	if ($page <= 0) $page = 1;
	$per_page = 6; // Set how many records do you want to display per page.
	$startpoint = ($page * $per_page) - $per_page;
	$statement="";
	$query_string = "?";
	if (isset($_GET['sort'])){	
		$query_string = "?sort=".$_GET['sort']."&";
		$statement = $_GET['sort'];
	}

	$entries = $db->get_random_entries ($statement,$per_page,$page,$url=$query_string,$startpoint,$per_page);
	
	$settings_start = $db->get_settings_by_setting_name("start_date");
	$settings_end = $db->get_settings_by_setting_name("end_date");
	$start_date = $settings_start['settings_value'];
	$end_date = $settings_end ['settings_value'];
	$contest_over = false;
    
	if ($start_date == "" || $end_date == ""){
		// Contest start and end didnt configured yet
		 
	}else {
		// Contest is configured 
		$paymentDate = date('Y-m-d');
    $paymentDate=date('Y-m-d', strtotime($paymentDate));;
    //echo $paymentDate; // echos today! 
    $contractDateBegin = date('Y-m-d', strtotime($start_date));
    $contractDateEnd = date('Y-m-d', strtotime($end_date));
    if (($paymentDate > $contractDateBegin) && ($paymentDate < $contractDateEnd))
    {
      
    }
    else
    {
    	if ($paymentDate < $contractDateEnd){
    		
    	}else {
    		$contest_over = true;		
    	}
      
    }
	}

	?>	
		<style type="text/css">
		.pagination li a.active{
			background-color: #0d83dd;
		}
		
		</style>
		<section id="page-gallery">
			<div class="fix container">
				<div class="fix row">
					<h1 style="width:40%; float:left"><?php echo $lang_random_entries;?></h1>
					<form action="" method="GET" class="form_sort">
					<?php 
					$selected_most_voted = "";
					$selected_least_voted = "";
					$selected_latest = "";
					$selected_oldest = "";
					if ($_GET['sort']){
						if ($_GET['sort']!==""){

							switch ($_GET['sort']) {
								case '1':
									$selected_most_voted = "selected='selected'";
									break;
								case '2':
									$selected_least_voted = "selected='selected'";
									break;
								case '3':
									$selected_latest = "selected='selected'";
									break;
								case '4':
									$selected_oldest = "selected='selected'";
									break;
								default:
									# code...
									break;
							}

						}
					}

					?>

					<select name="sort" class="sort" style="width:40%; float:right; margin:15px;">
							<option value=""><?php echo $lang_sort_by;?></option>
							<option value="1" <?php echo $selected_most_voted;?> ><?php echo $language_most_votes;?></option>
							<option value="2" <?php echo $selected_least_voted;?> ><?php echo $language_least_votes;?></option>
							<option value="3" <?php echo $selected_latest;?> ><?php echo $language_latest;?></option>
							<option value="4" <?php echo $selected_oldest;?> ><?php echo $language_oldest;?></option>
					</select>
					
				<?php if (isset($_GET['page'])){?>
					<input type="hidden" name="page" value="<?php echo $_GET['page'];?>"/>
				<?php }?>		
				</form>
					<div style="clear:both;"></div>
					<div class="fix col-sm-12 gallery clear">
						
						<?php 
						if ($entries){?>
						<?php 
						foreach ($entries['entries'] as $key => $value) {
								$id = $value['id'];
								?>
						
																	<!-- Gallery Items  -->
						<div class="fix col-sm-4">
							<div class="fix gallery-item">
							
							<!-- Modal Tiger  and Thumbnails-->
							
								<a data-toggle="modal" href="#modal-item-<?php echo $value['id']?>" >
									<img class="photo_<?php echo $id;?>"  src="uploads/<?php echo $value ['photo']?>" alt="" />
								</a>
								
							<!-- thumbnails Share info -->
							
								<div class="item-info">
									<ul class="post-info">
										<li><?php echo $lang_by_text;?>: <span><?php echo $value['first_name'] . " ". $value['last_name'];?></span> </li>
										<li><?php echo $lang_votes_text;?>: <span class="vote_count_<?php echo $value['id'];?>"><?php echo $value['votes'];?></span></li>
									</ul>
									<ul class="share">
										<li class="share_to_fb" data-id="<?php echo $value['id']?>"><?php echo $lang_share_text;?></li>
											

											<?php if ($fb_logged_in){?>
                                        <li class="vote" data-id="<?php echo $value['id'];?>">
												<?php echo $lang_vote_text;?>
											<?php }else{?>
                                        <li class="vote" data-id="<?php echo 'null';?>">
												<a data-id2="<?php echo $value['id'];?>" href="<?php  if (!$fb_logged_in && !$inside_fb){ echo $enter_contest_url;}else { echo str_replace('dummy',$value['id'], $enter_contest_url);} ?>" target="_top"><?php echo $lang_vote_text;?></a>
											<?php }?>
											
										</li>
									</ul>
								</div>

								
							<!--  Main Modal With Large Image-->	
							
								<div class="modal fade" id="modal-item-<?php echo $value['id']?>" style="display:none">
								
									<div class="top-modal">
										<ul class="post-info">
											<li>By: <span><?php echo $value['first_name']." ".$value['last_name'];?></span> </li>
										</ul>
										
										<ul class="close">
											<li class="modal-close" data-dismiss="modal">X</li>
										</ul>
									</div>
									
									<img src="uploads/<?php echo $value['photo'];?>" alt="" title="" />
									
									<div class="bottom-modal">
										<ul class="post-info">
											<li><?php echo $lang_votes_text;?>: <span class="vote_count_<?php echo $value['id'];?>"><?php echo $value['votes'];?></span></li>
										</ul>
										
										<ul class="share">
										<li class="share_to_fb" data-id="<?php echo $value['id']?>"><?php echo $lang_share_text;?></li>

													<?php if ($fb_logged_in){?>
                                            <li class="vote" data-id="<?php echo $value['id'];?>">
												<?php echo $lang_vote_text;?>
											<?php }else{?>
                                            <li class="vote" data-id="<?php echo "null";?>">

                                            <a data-id2="<?php echo $value['id'];?>" href="<?php  if (!$fb_logged_in && !$inside_fb){ echo $enter_contest_url;}else { echo str_replace('dummy',$value['id'], $enter_contest_url);} ?>" target="_top"><?php echo $lang_vote_text;?></a>
											<?php }?>
											
												</li>
											<li class="modal-close" data-dismiss="modal"><?php echo $lang_close_text;?></li>
										</ul>
									</div>	
								
								</div> 
								
								<!-- ./ Modal -->
								
								
							</div>
						</div>
						<!--  ./Gallery Items  -->



						<?php }
						?>






						<?php } else {?>
							<p><?php echo $lang_no_entries;?></p>
						<?php }
						?>


						
						<!-- Gallery Items  -->
					
						
						
						
					</div>
					<?php if ($entries['pagination']!==""){?>


					<div class="col-sm-12 text-center page-nav">
					<?php echo $entries['pagination'];?>
					</div>
					<?php }?>


				</div>
			</div>
		</section>
	<!-- /.Enter page Are -->
	
	<div class="clearfix"></div>
	<?php include_once ("includes/footer.php");?>
<?php 
    if (isset($_SESSION['user'])){
    	 $user =$_SESSION['user'];
    $facebook_email = $user->getProperty('email');
    }else {
    	$facebook_email="";
    }
    ?>
		<script type="text/javascript">
		jQuery (document).ready (function (){
		var f_email = "<?php echo $facebook_email;?>";
		jQuery (".vote").on ("click" , function(){
		var entry_id = jQuery(this).data("id");
		<?php if ($contest_over){?>
			alert ("You Cannot Vote Now Contest is Over");
		<?php }else {?>
            if (entry_id == null)
            {

                return;
            }

			jQuery (".vote_count_"+entry_id).html("<img src='img/ajax.gif'/>");	
		jQuery.post ("ajax.php" , {"ajax":true ,"method":"vote", "eid":entry_id,"email":f_email} , function (response){
			jQuery (".vote_count_"+entry_id).html(response.votes_count);
			alert (response.message);
		},'json');


		<?php }?>
		

		});

							jQuery(".sort").on ("change",function(){
								jQuery(".form_sort").submit();
							});
				
	});

	</script>
	<?php 
	$settings_share_text_title = $db->get_settings_by_setting_name("share_text_title");
	$share_text_title = $settings_share_text_title['settings_value'];

	$settings_share_text_sub_title = $db->get_settings_by_setting_name("share_text_sub_title");
	$share_text_sub_title = $settings_share_text_sub_title['settings_value'];
	
	$settings_share_text_description = $db->get_settings_by_setting_name("share_text_description");
	$share_text_description = $settings_share_text_description['settings_value'];
	
$share_url = "";
	$share_platform = "";
	if (contains('https://apps.facebook.com',$_SESSION['pageurl'])){
		// it is canvas app 
		$share_url = $_SESSION["pageurl"]."?app_data=";
		$share_platform = "canvas";
	}else{

	if ($inside_fb){
		$share_url = $_SESSION["pageurl"]."&app_data=";
		$share_platform = "fanpage";
	}else{
		$share_url = $_SESSION["pageurl"]."?app_data=";
		$share_platform = "website";
	}		

	}

	
$settings_site_url = $db ->get_settings_by_setting_name("main_site_url");
$main_site_url = $settings_site_url['settings_value'];
$share_url = $main_site_url."?platform=".$share_platform."&app_data=";

	


	function contains($needle, $haystack)
{
    return strpos($haystack, $needle) !== false;
}

	
	?>
	<script type="text/javascript">
            $( document ).ready(function() {
                // Share button has been given id share_btn and on click following handler is used
                $( ".share_to_fb" ).click(function() {
                    // Preparing required variables for FB.ui call
                    // To prepare these variables settings / variables from config.php file are used
                    var id = $(this).data("id");
                    var photo_element = $(".photo_"+id);
                    var img_src = $(photo_element)[0].src;
                    var img_src_new = img_src.replace("http://", ""); 
                    img_src_new = img_src.replace("https://", ""); 
                    

                    var publish = {
                        method: "feed",
                        name: "<?php echo $share_text_title; ?>",           // Title of your post
                        caption: "<?php echo $share_text_sub_title; ?>",    // Sub-Title of your post
                        description: ("<?php echo $share_text_description; ?>"),
                         link: "<?php echo $share_url; ?>"+id,           // Link where you want to take the users when they click on your post
                        picture: img_src_new      // Picture for your post
                        
                    };

                    FB.ui(publish, function(response){

					// Check if the post was actually made or was cancelled
					if (response && !response.error_code) {
					// If post was made 
					// show thank you pop up delete 
					alert('Thank you for posting');
					} else {
					// If somehow user closed the pop up then show following pop up
					alert('Please try again later! Looks like you closed the share window or there was some error.');
					}
					// end of FB.ui
					});
                    // Actual call to Facebook for share feed, note "publish" variable is passed
                    
                });
              
				<?php if (!$inside_fb){?>

            		$(".vote").find("a").on("click",function(e){
            			e.preventDefault();
            			var url_redirect = $(this).attr("href");
            			var eid = $(this).data("id2");
            			$.post ("ajax.php", {"ajax":"1","method":"redirect","eid":eid} , function (data){
            				location.replace(url_redirect);
            			});

            		});

            	<?php }?>

            });
        </script>
