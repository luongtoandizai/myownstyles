<?php

/*
 * Customize text in your own language
 */

// Menu Languages 
$lang_home_header_text = "HOME";
$lang_gallery_header_text = "GALLERY";
$lang_enter_now_header_text = "ENTER NOW";
$lang_rules_header_text = "RULES";

// Footer Languages
$lang_footer_text="© 2013 Henoz Photo Contest. All Rights Reserved.";

// Home page text
$lang_heading_home_page="Win This Script for FREE";
$lang_sub_heading_home_page="Are you looking to get this script for FREE? Do not miss it and enter now.";
$lang_button_home_page="Enter Contest";
$lang_no_entries="No Entries Yet";
$lang_random_entries="Random Entries";
$lang_winners_of_contest = "Winners of Contest";


// Gallery Items Text 
$lang_vote_text="VOTE";
$lang_share_text="SHARE";
$lang_by_text="By";
$lang_votes_text="Votes";
$lang_close_text="close";


//Enter contest page text
$lang_heading_enter_contest_text="Enter Now";
$lang_first_name_text="First Name";
$lang_last_name_text="Last Name";
$lang_email_address_text="Email Address";
$lang_phone_number_text="Phone Number";
$lang_upload_photo_text="Upload Your Photo";
$lang_submit_button_enter_contest = "SUBMIT";

//blue are on right side
$lang_heading_blue_box ="Instructions";
$lang_instruction_first_text="Photo size must be 1 mb";
$lang_instruction_second_text="For best result upload photo 800px*800px";
$lang_instruction_third_text="All Fields are required";


// Success and Error Messages 

$lang_contest_not_started = "Contest Didnt Started yet";
$lang_contest_over = "Sorry You Are Late Contest is over";
$language_fill_all_fields = "Please Enter All Fields.";
$language_invalid_phone_number = "Invalid Phone Number";
$language_invalid_email_address = "Invalid Email Address";
$language_photo_required = "Please Upload Photo.";
$language_error_uploading_photo = "Error Uploading Photo.";
$language_error_invalid_photo = "Invalid Photo Uploaded.";
$language_entry_sent_admin_approval = "Entry Sent For Admin Approval.";
$language_entry_displayed_on_gallery = "Entry Displayed on Gallery.";
$language_maximum_entry_limit_reached = "Maximum Entries Limit Per user Reached";

// Sorting Drop Downs 
$lang_sort_by = "Sort By:";
$language_most_votes = "Most Votes";
$language_least_votes = "Least Votes";
$language_latest = "Latest";
$language_oldest = "Oldest";