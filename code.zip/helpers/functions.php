<?php 

function validate_email_address ($email){
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
return true;
}else{
	return false;
}
}

function generateRandomString($length = 10) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}



function export_users_to_csv($data){
	// This Function will export the data to csv file and download it 

if (mysql_num_rows($data)>0){
	// Data exists 
$file_name = generateRandomString();
$fp = fopen('../uploads/'.$file_name.'.csv', 'w');

$first_row =  array('User Name ','Email','Phone');
fputcsv($fp, $first_row);
while ($row=mysql_fetch_array($data)){
	$other_row = array (
		$row['first_name'].$row['last_name'] ,
		$row['email'],
		$row['phone']
		);
	fputcsv($fp, $other_row);
}

fclose($fp);

$file='../uploads/'.$file_name.'.csv'; //file location
   if (file_exists($file)) {

        //set appropriate headers
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();

        //read the file from disk and output the content.
        readfile($file);
        exit;
    }

}else {
	// Data doesnot exists

$file_name = generateRandomString();
$fp = fopen('../uploads/'.$file_name.'.csv', 'w');

$first_row =  array('Entry By','Email','Votes');
fputcsv($fp, $first_row);
fputcsv($fp, array("No Records Found"));

fclose($fp);

$file='../uploads/'.$file_name.'.csv'; //file location
   if (file_exists($file)) {

        //set appropriate headers
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();

        //read the file from disk and output the content.
        readfile($file);
        exit;
    }

}

}


function export_extries_to_csv($data){
	// This Function will export the data to csv file and download it 

if (mysql_num_rows($data)>0){
	// Data exists 
$file_name = generateRandomString();
$fp = fopen('../uploads/'.$file_name.'.csv', 'w');

$first_row =  array('Entry By','Email','Votes','Created');
fputcsv($fp, $first_row);
while ($row=mysql_fetch_array($data)){
	$other_row = array (
		$row['first_name'].$row['last_name'] ,
		$row['email'],
		$row['votes'],
        $row['created']
		);
	fputcsv($fp, $other_row);
}

fclose($fp);

$file='../uploads/'.$file_name.'.csv'; //file location
   if (file_exists($file)) {

        //set appropriate headers
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();

        //read the file from disk and output the content.
        readfile($file);
        exit;
    }

}else {
	// Data doesnot exists

$file_name = generateRandomString();
$fp = fopen('../uploads/'.$file_name.'.csv', 'w');

$first_row =  array('Entry By','Email','Votes');
fputcsv($fp, $first_row);
fputcsv($fp, array("No Records Found"));

fclose($fp);

$file='../uploads/'.$file_name.'.csv'; //file location
   if (file_exists($file)) {

        //set appropriate headers
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();

        //read the file from disk and output the content.
        readfile($file);
        exit;
    }

}

}

?>