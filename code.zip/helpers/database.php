<?php 

class database{
function __construct (){

    // constructor of the function 
    // create database connection there 
$host = DB_HOST;
$user_name = DB_USERNAME;
$db_pass = DB_PASSWORD;
$db_name = DB_NAME;
$conn = mysql_connect("$host", "$user_name", "$db_pass");
if ($conn){

}else {
    echo 'Unable to connect to database please check config file.';
    die ();
}

if (mysql_select_db("$db_name")){

}else {
    echo 'Unable to select database please check config file.';
    die ();
}

}


public function get_settings_by_setting_name($name){
	// This function will be used to get the settings based on setting name
$query =  "select * from ".PREFIX."site_settings where settings_title = '".$name."'";
$result = mysql_query ($query);
if (mysql_num_rows($result)>0){
//  results are found so return row 
	return mysql_fetch_array($result);
}else {
// no results are found so return false
	return false;
}
}

public function get_admin_user_by_id($user_id){

$query =  "select admin_email , admin_name from ".PREFIX."admin_login where id = '".$user_id."'";
$result = mysql_query ($query);
if (mysql_num_rows($result)>0){
//  results are found so return row 
	return mysql_fetch_array($result);
}else {
// no results are found so return false
	return false;
}

}


public function update_admin_details($admin_email , $admin_name , $admin_pass,$user_id){
$password_statement = "";

if ($admin_pass!==""){
	$password_statement = ",admin_password='".md5($admin_pass)."'";
}
$update_query ="
UPDATE ".PREFIX."admin_login
SET 
admin_email='".$admin_email."',
admin_name='".$admin_name."'".$password_statement."
WHERE id='".$user_id."';";
mysql_query($update_query);
}

public function get_default_settings(){

$query =  "select * from ".PREFIX."site_settings";
$result = mysql_query ($query);
$settings = array ();
if (mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$settings[$row['settings_title']] = $row['settings_value'];
	}
	return $settings;
}else {
// no results are found so return false
	return false;
}

}


public function update_new_settings($settings){
foreach ($settings as $key => $value) {
 $settings_query = 'update '.PREFIX.'site_settings set settings_value = "'.$value.'" where settings_title = "'.$key.'"';	
 mysql_query($settings_query);	
}
}

public function save_banners($banners){
	$truncate_query = "TRUNCATE ".PREFIX."banners";
	mysql_query($truncate_query);
	foreach ($banners as $banner) {
		$insert_banner_query = "insert into ".PREFIX."banners values ('', '".$banner."')";
 		mysql_query($insert_banner_query);	

	}
}

public function get_front_banners(){

$query =  "select * from ".PREFIX."banners";
$result = mysql_query ($query);
$banners = array ();
if (mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$banners[] = $row['banner'];
	}
	return $banners;
}else {
// no results are found so return false
	return false;
}

}

public function save_user ($fields){
$first_name = $fields['first_name'];
$last_name = $fields ['last_name'];
$email = $fields ['email'];
$fbid = $fields ['fbid'];
$phone = "";
$user_query =  "select * from ".PREFIX."users where email = '".$email."'";
$user_result = mysql_query ($user_query);
if (mysql_num_rows($user_result)>0){
	$row = mysql_fetch_array($user_result);
	$user_id = $row['user_id'];
}else {
$insert_entry_query = "insert into ".PREFIX."users values ('', '".$first_name."' , '".$last_name."' ,'".$email."' , '".$phone."' ,'0','".$fbid."')";
mysql_query($insert_entry_query);	
$user_id = mysql_insert_id();
}

return $user_id;
}

public function save_contest($fields,$approval){

$first_name = $fields['first_name'];
$last_name = $fields ['last_name'];
$email = $fields ['email'];
$phone = $fields ['phone'];
$photo = $fields ['photo'];
$fbid = $fields ['fbid'];
$created = date("Y-m-d H:i:s");
$entries_per_user = $this->get_settings_by_setting_name("entries_per_user");
$entries = intval($entries_per_user['settings_value']); 

$user_id = $this->save_user($fields);

$existing_entries_query =  "select * from ".PREFIX."entries where user_id = '".$user_id."'";
$existing_entries_result = mysql_query ($existing_entries_query);

if (mysql_num_rows($existing_entries_result) < $entries){
$insert_entry_query = "insert into ".PREFIX."entries values ('', '".$photo."' , '".$created."' ,'".$user_id."' ,'$approval')";
mysql_query($insert_entry_query);	
return true;
}else {
	return false;
}


}


public function get_random_entries_front($contest_over){

 $query_winners =  "
SELECT entries.*,
(select count(*) from ".PREFIX."votes where entries.id = votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id where ".PREFIX."entries.approved =-1 or ".PREFIX."entries.approved =-2 or ".PREFIX."entries.approved =-3 order by ".PREFIX."entries.approved limit 0,3 ";

$query_random =  "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id where ".PREFIX."entries.approved =1 ORDER BY RAND() limit 0,3 ";

$final_query = "";

$result_type="Random Entries";


if ($contest_over){
	// contest is over we will show 1st 2nd 3rd on front 
	// these will be shown when all positions will be set by admin side 


$result_winners = mysql_query ($query_winners);
if (mysql_num_rows($result_winners)>=2){
// positions holders are set 
	$final_query = $query_winners;
	$result_type="Winners of Contest";

}else {
// Position holders are not set so show random
	$final_query = $query_random;
	$result_type="Random Entries";
}
}else {
// Contest is active so show random 
	$final_query = $query_random;
	$result_type="Random Entries";
}




$result = mysql_query ($final_query);
// Get total count of results 


$entries = array ();
if ($result && mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$entries[] = $row;
	}
	$response = array ();
	$response['entries']= $entries;
	$response['result_type']=$result_type;
	return $response;
}else {
// no results are found so return false
	$response = array ();
	$response['entries']= false;
	$response['result_type']=$result_type;
	return $response;
	
}

}

public function get_random_entries($query,$per_page=10,$page=1,$url='?',$startpoint,$per_page){
 $sort = $query;
$order_by_clause  = "";
if ($sort!==""){
	// sorting parameter is available
	/*
	<option value="">Sort By:</option>
							<option value="1">Most Voted</option>
							<option value="2">Least Voted</option>
							<option value="3">Latest</option>
							<option value="4">Oldest</option>
	*/
	switch ($sort) {
		case '1':
			$order_by_clause = " ORDER BY votes DESC ";
			break;
		case '2':
			$order_by_clause = " ORDER BY votes ASC ";
			# code...
			break;
		case '3':
			$order_by_clause = " ORDER BY entries.id DESC ";
			# code...
			break;
		case '4':
		$order_by_clause = " ORDER BY entries.id ASC ";
			# code...
			break;
		default:
			
			break;
	}
}

$query =  "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id where ".PREFIX."entries.approved =1 $order_by_clause  LIMIT $startpoint , $per_page ";
$result = mysql_query ($query);
// Get total count of results 
$total_query =  "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id where approved =1";
$total_result = mysql_query ($total_query);
$total_res=mysql_num_rows($total_result);


$entries = array ();
if (mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$entries[] = $row;
	}
	$response = array ();
	$response['pagination']=$this->get_pagination_results($query,$per_page,$page,$url,$total_res);
	$response['entries']= $entries;
	return $response;
}else {
// no results are found so return false
	return false;
}

}

public function get_pagination_results($query,$per_page=10,$page=1,$url='?',$total){
	// this function will get the pagination results 

	$adjacents = "2";
      
    $prevlabel = "&lsaquo; Prev";
    $nextlabel = "Next &rsaquo;";
    $lastlabel = "Last &rsaquo;&rsaquo;";
      
    $page = ($page == 0 ? 1 : $page); 
    $start = ($page - 1) * $per_page;                              
      
    $prev = $page - 1;                         
    $next = $page + 1;
      
    $lastpage = ceil($total/$per_page);
      
    $lpm1 = $lastpage - 1; // //last page minus 1
      
    $pagination = "";
    if($lastpage > 1){  
        $pagination .= "<ul class='pagination pagination-sm'>";
        $pagination .= "<li class='page_info'>Page {$page} of {$lastpage}</li>";
              
            if ($page > 1) $pagination.= "<li><a href='{$url}page={$prev}'>{$prevlabel}</a></li>";
              
        if ($lastpage < 7 + ($adjacents * 2)){  
            for ($counter = 1; $counter <= $lastpage; $counter++){
                if ($counter == $page)
                    $pagination.= "<li><a class='active'>{$counter}</a></li>";
                else
                    $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";                   
            }
          
        } elseif($lastpage > 5 + ($adjacents * 2)){
              
            if($page < 1 + ($adjacents * 2)) {
                  
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++){
                    if ($counter == $page)
                        $pagination.= "<li><a class='active'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";                   
                }
                $pagination.= "<li class='dot'>...</li>";
                $pagination.= "<li><a href='{$url}page={$lpm1}'>{$lpm1}</a></li>";
                $pagination.= "<li><a href='{$url}page={$lastpage}'>{$lastpage}</a></li>"; 
                      
            } elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                  
                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='active'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";                   
                }
                $pagination.= "<li class='dot'>..</li>";
                $pagination.= "<li><a href='{$url}page={$lpm1}'>{$lpm1}</a></li>";
                $pagination.= "<li><a href='{$url}page={$lastpage}'>{$lastpage}</a></li>";     
                  
            } else {
                  
                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='active'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";                   
                }
            }
        }
          
            if ($page < $counter - 1) {
                $pagination.= "<li><a href='{$url}page={$next}'>{$nextlabel}</a></li>";
                $pagination.= "<li><a href='{$url}page=$lastpage'>{$lastlabel}</a></li>";
            }
          
        $pagination.= "</ul>";       
    }
      
    return $pagination;

}


public function get_entries_all($sort_by,$query,$per_page=10,$page=1,$url='?',$startpoint,$per_page,$search_text,$export_csv){
$sort_by_clause = "";
if ($sort_by !==""){
	switch ($sort_by) {
		case '1':
			$sort_by_clause = " where approved =1";
		    break;
		case '2':
		    $sort_by_clause = " where approved =0";
		    break;
		case '3':
			$sort_by_clause = " order by votes DESC";
			break;
		case '4':
			$sort_by_clause = " order by id DESC";
			break;
		case '5':
			$sort_by_clause = " order by id ASC";
			break;	
	}
}		

$search_query = "";
if ($search_text !==""){
	$search_query = " where ".PREFIX."users.first_name like '%$search_text%' or ".PREFIX."users.last_name like '%$search_text%' or ".PREFIX."users.email like '%$search_text%'";	
}

$query =  "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id $search_query $sort_by_clause  LIMIT $startpoint , $per_page";
$result = mysql_query ($query);



$total_query = "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id $sort_by_clause";
$total_result = mysql_query ($total_query);
$total_res=mysql_num_rows($total_result);


if ($export_csv){
	export_extries_to_csv($total_result);
}

$entries = array ();
if (mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$entries[] = $row;
	}
	$response = array ();
	$response['pagination']=$this->get_pagination_results($query,$per_page,$page,$url,$total_res);
	$response['entries']= $entries;
	
	return $response;
}else {
// no results are found so return false
	return false;
}

}




public function get_users_details($sort_by,$query,$per_page=10,$page=1,$url='?',$startpoint,$per_page,$search_text,$export_csv){

$sort_by_clause = "";
if ($sort_by !==""){
	switch ($sort_by) {
		case '1':
			$sort_by_clause = " order by entries DESC";
		    break;
		case '2':
		    $sort_by_clause = " order by votes DESC"; 
		    break;
		case '3':
			$sort_by_clause = " order by user_id DESC";
			break;
		case '4':
			$sort_by_clause = " order by user_id ASC";
			break;	
	}
}		

$search_query = "";
if ($search_text !==""){
	$search_query = " where ".PREFIX."users.first_name like '%$search_text%' or ".PREFIX."users.last_name like '%$search_text%' or ".PREFIX."users.email like '%$search_text%'";	
}

$query =  "
SELECT ".PREFIX."users.* ,
(select count(*) from ".PREFIX."entries where ".PREFIX."entries.user_id = ".PREFIX."users.user_id) as entries,
(select count(*) from ".PREFIX."votes where ".PREFIX."votes.email = ".PREFIX."users.email) as votes
from ".PREFIX."users $search_query $sort_by_clause LIMIT $startpoint , $per_page";
$result = mysql_query ($query);

$total_query = "
SELECT ".PREFIX."users.* ,
(select count(*) from ".PREFIX."entries where ".PREFIX."entries.user_id = ".PREFIX."users.user_id) as entries,
(select count(*) from ".PREFIX."votes where ".PREFIX."votes.email = ".PREFIX."users.email) as votes
from ".PREFIX."users $sort_by_clause";
$total_result = mysql_query ($total_query);
$total_res=mysql_num_rows($total_result);
if ($export_csv){
	export_users_to_csv($total_result);
}

$entries = array ();
if (mysql_num_rows($result)>0){
//  results are found so return row 
	while($row=mysql_fetch_assoc($result)){
		$entries[] = $row;
	}

	$response = array ();
	$response['pagination']=$this->get_pagination_results($query,$per_page,$page,$url,$total_res);
	$response['entries']= $entries;
	
	return $response;
	
}else {
// no results are found so return false
	return false;
}
}

public function get_all_users_count (){

$query =  "
SELECT ".PREFIX."users.* ,
(select count(*) from ".PREFIX."entries where ".PREFIX."entries.user_id = ".PREFIX."users.user_id) as entries,
(select count(*) from ".PREFIX."votes where ".PREFIX."votes.email = ".PREFIX."users.email) as votes
from ".PREFIX."users";
$result = mysql_query ($query);
return mysql_num_rows($result);

}

public function approve_entry($id,$approve){
	// This function approves the entry on the base of entry id 
	$update_entry_query = "update ".PREFIX."users set entered = '".$approve."' where user_id = '".$id."'";
 	mysql_query($update_entry_query);	
}

public function delete_entry($eid){
$query =  "delete from ".PREFIX."entries where id = '$eid'";
mysql_query ($query);
}

public function live_entry($id,$approve){
	// This function approves the entry on the base of entry id 
	$update_entry_query = "update ".PREFIX."entries set approved = '".$approve."' where id = '".$id."'";
 	mysql_query($update_entry_query);	
}


public function get_entries_count_by_user_id($user_id){

$query =  "Select * from ".PREFIX."entries where user_id = $user_id";
$result = mysql_query ($query);
return mysql_num_rows($result);

}

public function delete_user($user_id){
// This function deletes the user from user table 
$delete_user_query = "delete from ".PREFIX."entries where user_id = '$user_id'";
$delete_entries_query ="delete from ".PREFIX."users where user_id = '$user_id'";
mysql_query($delete_user_query);
mysql_query($delete_entries_query);
}

public function insert_vote($eid,$email){
	session_start();
	$default_settings = $this->get_default_settings();
	$number_of_votes = $default_settings ['number_of_votes'];
	$vote_days = $default_settings ['votes_days'];
	$voting_choice = $default_settings['voting_choice'];
	$format = "Y-m-d H:i:s";
	$date = date ($format); 
	$format2 = "Y-m-d";
	$date2 = date ($format2); 
	
	$start_date =  date ($format, strtotime ( '-'.intval($vote_days).' day' . $date ) ); 
	$current_user_id = $_SESSION['userid'];
	// if ($vote_days == 1){
	// $limit_query = "select * from votes WHERE created BETWEEN '$date2 00:00:00' AND '$date' AND entry_id ='$eid'";
	// }else {
	// $limit_query = "select * from votes WHERE created BETWEEN '$start_date' AND '$date' AND entry_id ='$eid'";
	// }

	if ($voting_choice ==1){
	// Per Photo is selected	
	
	$where_clause = "";
	if ($vote_days == 1){
	$where_clause = " WHERE created BETWEEN '$date2 00:00:00' AND '$date' AND entry_id ='$eid' AND user_id ='$current_user_id'";
	}else {
	$where_clause = " WHERE created BETWEEN '$start_date' AND '$date' AND entry_id ='$eid' AND user_id ='$current_user_id'";
	}

	$limit_query = "
					SELECT
".PREFIX."votes.vote_id,
".PREFIX."votes.entry_id,
".PREFIX."votes.email,
".PREFIX."votes.created,
".PREFIX."users.email,
".PREFIX."users.user_id
FROM
".PREFIX."votes
INNER JOIN ".PREFIX."users ON ".PREFIX."votes.email = ".PREFIX."users.email $where_clause";
	
	}else{
		// Voting choice is per contest 
	$where_clause = "";
	if ($vote_days == 1){
	$where_clause = " WHERE created BETWEEN '$date2 00:00:00' AND '$date' AND user_id ='$current_user_id'";
	}else {
	$where_clause = " WHERE created BETWEEN '$start_date' AND '$date' AND user_id ='$current_user_id'";
	}

	$limit_query = "
					SELECT
".PREFIX."votes.vote_id,
".PREFIX."votes.entry_id,
".PREFIX."votes.email,
".PREFIX."votes.created,
".PREFIX."users.email,
".PREFIX."users.user_id
FROM
".PREFIX."votes
INNER JOIN ".PREFIX."users ON ".PREFIX."votes.email = ".PREFIX."users.email  $where_clause";
				
	}	
	


	$limit_res = mysql_query($limit_query);
	
	$response = array ();
	if (mysql_num_rows($limit_res) < intval($number_of_votes)){
		// Insert the Vote
		$created_date = date ("Y-m-d H:i:s");
		$insert_vote_query = "insert into ".PREFIX."votes values ('', '".$eid."' , '$email','$created_date')";
		mysql_query($insert_vote_query);
		$res= mysql_query("select * from ".PREFIX."votes where entry_id ='$eid'");
		$response['message']="Voted Successfully";
		$response['votes_count']= mysql_num_rows($res); 
	}else {
		$res= mysql_query("select * from ".PREFIX."votes where entry_id ='$eid'");
		$response['message']="Vote Limit Reached";
		$response['votes_count']= mysql_num_rows($res);
	}
	echo json_encode($response);
	die ();	
}


public function get_total_users_count(){
$res= mysql_query("select * from ".PREFIX."users");
return mysql_num_rows($res);
}
public function get_total_votes_count(){
	$res= mysql_query("select * from ".PREFIX."votes");
return mysql_num_rows($res);
}
public function get_total_entries_count(){
	$res= mysql_query("select * from ".PREFIX."entries");
return mysql_num_rows($res);
}
public function get_entry_by_id($eid){
$total_query =  "
SELECT ".PREFIX."entries.*,
(select count(*) from ".PREFIX."votes where ".PREFIX."entries.id = ".PREFIX."votes.entry_id) as votes,
".PREFIX."users.*
 from ".PREFIX."entries
 JOIN ".PREFIX."users 
ON ".PREFIX."entries.user_id=".PREFIX."users.user_id where ".PREFIX."entries.id =$eid";
$total_result = mysql_query ($total_query);

return $total_result;
}


}

?>